import numpy as np
import shutil
import os
import torch
import random
import nibabel as nib
import networkx as nx
from itertools import combinations
# import multiprocessing as mp
from concurrent.futures import ThreadPoolExecutor
from functools import partial
from torch import nn
from time import time
from typing import Union, List, Tuple
from scipy import ndimage
from sklearn.neighbors import NearestNeighbors
from dynamic_network_architectures.building_blocks.simple_conv_blocks import StackedConvBlocks
from dynamic_network_architectures.building_blocks.helper import get_matching_convtransp
from dynamic_network_architectures.building_blocks.residual_encoders import ResidualEncoder
from dynamic_network_architectures.building_blocks.plain_conv_encoder import PlainConvEncoder

from nnunetv2.training.nnUNetTrainer.variants.network_architecture.torch_nn import BasicConv, batched_index_select, act_layer
from nnunetv2.training.nnUNetTrainer.variants.network_architecture.torch_edge import DenseDilatedKnnGraph
from nnunetv2.training.nnUNetTrainer.variants.network_architecture.torch_edge_train import DenseDilatedKnnGraph_Train
from nnunetv2.training.nnUNetTrainer.variants.network_architecture.torch_edge_with_mask import DenseDilatedKnnGraph_With_Mask
from nnunetv2.training.loss.compound_losses import DC_and_CE_loss
from nnunetv2.training.loss.dice import get_tp_fp_fn_tn, MemoryEfficientSoftDiceLoss
from nnunetv2.training.nnUNetTrainer.variants.network_architecture.pos_embed import get_2d_relative_pos_embed, get_3d_relative_pos_embed
import torch.nn.functional as F
from timm.models.layers import DropPath
from einops import rearrange
from batchgenerators.utilities.file_and_folder_operations import maybe_mkdir_p
from scipy.ndimage import distance_transform_edt, morphology, generate_binary_structure
from skimage.morphology import cube
    
class OptInit:
    def __init__(self, drop_path_rate=0., pool_op_kernel_sizes_len=4):
        # self.k = [4, 8, 16] + [32] * (pool_op_kernel_sizes_len - 3) 
        self.k = [8, 8, 8] + [8] * (pool_op_kernel_sizes_len - 3) 
        self.conv = 'mr'  
        self.act = 'leakyrelu'
        self.norm = 'instance'
        self.bias = True
        self.dropout = 0.0  # dropout rate
        self.use_dilation = True  # use dilated knn or not
        self.epsilon = 0.2  # stochastic epsilon for gcn
        self.use_stochastic = True 
        self.drop_path = drop_path_rate
        # number of basic blocks in the backbone
        self.blocks = [1] * (pool_op_kernel_sizes_len - 2) + [1, 1] 
        # number of reduce ratios in the backbone
        self.reduce_ratios = [4, 2, 1, 1] + [1] * (pool_op_kernel_sizes_len - 4) #[4, 2, 1, 1] + [1] * (pool_op_kernel_sizes_len - 4) 

class UNetDecoder_with_features(nn.Module):
    def __init__(self,
                 encoder: Union[PlainConvEncoder, ResidualEncoder],
                 patch_size: List[int],
                 strides: Union[int, List[int], Tuple[int, ...]],
                 num_classes: int,
                 n_conv_per_stage: Union[int, Tuple[int, ...], List[int]],
                 deep_supervision, nonlin_first: bool = False):
        """
        This class needs the skips of the encoder as input in its forward.

        the encoder goes all the way to the bottleneck, so that's where the decoder picks up. stages in the decoder
        are sorted by order of computation, so the first stage has the lowest resolution and takes the bottleneck
        features and the lowest skip as inputs
        the decoder has two (three) parts in each stage:
        1) conv transpose to upsample the feature maps of the stage below it (or the bottleneck in case of the first stage)
        2) n_conv_per_stage conv blocks to let the two inputs get to know each other and merge
        3) (optional if deep_supervision=True) a segmentation output Todo: enable upsample logits?
        :param encoder:
        :param num_classes:
        :param n_conv_per_stage:
        :param deep_supervision:
        """
        super().__init__()
        self.deep_supervision = deep_supervision
        self.encoder = encoder
        self.num_classes = num_classes
        n_stages_encoder = len(encoder.output_channels)
        if isinstance(n_conv_per_stage, int):
            n_conv_per_stage = [n_conv_per_stage] * (n_stages_encoder - 1)
        assert len(n_conv_per_stage) == n_stages_encoder - 1, "n_conv_per_stage must have as many entries as we have " \
                                                          "resolution stages - 1 (n_stages in encoder - 1), " \
                                                          "here: %d" % n_stages_encoder

        transpconv_op = get_matching_convtransp(conv_op=encoder.conv_op)
        conv_op=encoder.conv_op
        self.conv_op = conv_op
        self.norm_op = encoder.norm_op
        self.norm_op_kwargs = encoder.norm_op_kwargs
        self.dropout_op = encoder.dropout_op

        img_shape_list = []
        n_size_list = []
        conv_layer_d_num = 0 #2
        pool_op_kernel_sizes = strides[1:]
        if conv_op == nn.Conv2d:
            h, w = patch_size[0], patch_size[1]
            img_shape_list.append((h, w))
            n_size_list.append(h * w)

            for i in range(len(pool_op_kernel_sizes)):
                h_k, w_k = pool_op_kernel_sizes[i]
                h //= h_k
                w //= w_k
                img_shape_list.append((h, w))
                n_size_list.append(h * w)

        elif conv_op == nn.Conv3d:
            h, w, d = patch_size[0], patch_size[1], patch_size[2]
            img_shape_list.append((h, w, d))
            n_size_list.append(h * w * d)

            for i in range(len(pool_op_kernel_sizes)):
                h_k, w_k, d_k = pool_op_kernel_sizes[i]
                h //= h_k
                w //= w_k
                d //= d_k
                img_shape_list.append((h, w, d))
                n_size_list.append(h * w * d)
        else:
            raise ValueError("unknown convolution dimensionality, conv op: %s" % str(conv_op))

        img_min_shape = img_shape_list[-1]

        opt = OptInit(pool_op_kernel_sizes_len=len(strides))
        self.opt = opt
        self.opt.img_min_shape = img_min_shape

        self.conv_layer_d_num = conv_layer_d_num
                
        self.opt.n_size_list = n_size_list

        # we start with the bottleneck and work out way up
        stages = []
        evig_stages = []
        transpconvs = []
        stages_center = []
        # transpconvs_center = []
        seg_layers_for_evig = []
        seg_layers = []
        # center_layers = []
        
        for s in range(1, n_stages_encoder):
            input_features_below = encoder.output_channels[-s]
            input_features_skip = encoder.output_channels[-(s + 1)]
            stride_for_transpconv = encoder.strides[-s]
            transpconvs.append(transpconv_op(
                input_features_below, input_features_skip, stride_for_transpconv, stride_for_transpconv,
                bias=encoder.conv_bias
            ))
            # transpconvs_center.append(transpconv_op(
            #     input_features_below, input_features_skip, stride_for_transpconv, stride_for_transpconv,
            #     bias=encoder.conv_bias
            # ))

            # input features to conv is 2x input_features_skip (concat input_features_skip with transpconv output)
            if s == (n_stages_encoder-1): #< (n_stages_encoder-conv_layer_d_num):
                stages.append(StackedConvBlocks(
                    n_conv_per_stage[s-1] - 1, encoder.conv_op, 2 * input_features_skip, input_features_skip,
                    # n_conv_per_stage[s-1], encoder.conv_op, 2 * input_features_skip, input_features_skip,
                    encoder.kernel_sizes[-(s + 1)], 1, encoder.conv_bias, encoder.norm_op, encoder.norm_op_kwargs,
                    encoder.dropout_op, encoder.dropout_op_kwargs, encoder.nonlin, encoder.nonlin_kwargs, nonlin_first
                ))
                evig_stages.append(Efficient_ViG_blocks(input_features_skip, img_shape_list[n_stages_encoder-(s + 1)], n_stages_encoder-conv_layer_d_num-(s + 1), conv_layer_d_num, opt=self.opt, conv_op=self.conv_op,
                    norm_op=self.norm_op, norm_op_kwargs=self.norm_op_kwargs, dropout_op=self.dropout_op))

            else:
                stages.append(StackedConvBlocks(
                n_conv_per_stage[s-1], encoder.conv_op, 2 * input_features_skip, input_features_skip,
                encoder.kernel_sizes[-(s + 1)], 1, encoder.conv_bias, encoder.norm_op, encoder.norm_op_kwargs,
                encoder.dropout_op, encoder.dropout_op_kwargs, encoder.nonlin, encoder.nonlin_kwargs, nonlin_first
            ))
                
        #     stages_center.append(StackedConvBlocks(
        #     n_conv_per_stage[s-1], encoder.conv_op, 2 * input_features_skip, input_features_skip,
        #     encoder.kernel_sizes[-(s + 1)], 1, encoder.conv_bias, encoder.norm_op, encoder.norm_op_kwargs,
        #     encoder.dropout_op, encoder.dropout_op_kwargs, encoder.nonlin, encoder.nonlin_kwargs, nonlin_first
        # ))
                
            # we always build the deep supervision outputs so that we can always load parameters. If we don't do this
            # then a model trained with deep_supervision=True could not easily be loaded at inference time where
            # deep supervision is not needed. It's just a convenience thing
            seg_layers_for_evig.append(encoder.conv_op(input_features_skip, num_classes, 1, 1, 0, bias=True))
            seg_layers.append(encoder.conv_op(input_features_skip, num_classes, 1, 1, 0, bias=True))
            # center_layers.append(encoder.conv_op(input_features_skip, num_classes, 1, 1, 0, bias=True))

        self.stages = nn.ModuleList(stages)
        self.stages_center = nn.ModuleList(stages_center)
        self.evig_stages = nn.ModuleList(evig_stages)
        self.transpconvs = nn.ModuleList(transpconvs)
        # self.transpconvs_center = nn.ModuleList(transpconvs_center)
        # self.center_layers = nn.ModuleList(center_layers)
        self.seg_layers = nn.ModuleList(seg_layers)
        self.seg_layers_for_evig = nn.ModuleList(seg_layers_for_evig)

    def forward(self, skips, windows_seg_targets_dict, windows_graph_edges_target_dict, windows_graph_nodes_dict, current_epoch, val_flag, test_flag):
        """
        we expect to get the skips in the order they were computed, so the bottleneck should be the last entry
        :param skips:
        :return:
        """
        lres_input = skips[-1]
        seg_outputs = []
        recurrent_num = 1

        for s in range(len(self.stages)):
            x = self.transpconvs[s](lres_input)
            x = torch.cat((x, skips[-(s+2)]), 1)
            x = self.stages[s](x)

            if s in [4]:
               
                loss_graph_mean_list = []
                for r in range(0, recurrent_num):
                    tmp = x

                    if test_flag:
                        x, loss_graph_mean, skel_pred = self.evig_stages[0](x, None, None, None, current_epoch, m2g2m=True, val_flag=False, test_flag=test_flag)
                    else:
                        x, loss_graph_mean = self.evig_stages[0](x, windows_seg_targets_dict[len(self.stages)-s-1], windows_graph_edges_target_dict[len(self.stages)-s-1], windows_graph_nodes_dict[len(self.stages)-s-1], current_epoch, m2g2m=True, val_flag=val_flag, test_flag=test_flag)
                    
                    x = x + tmp
                    loss_graph_mean_list.append(loss_graph_mean)

                if test_flag:
                    seg_output = self.seg_layers[-1](x)
                    seg_output = torch.cat((seg_output, skel_pred), 1)
                    seg_outputs.append(seg_output)
                else:
                    if self.deep_supervision:
                        seg_output = self.seg_layers[s](x)
                        seg_outputs.append(seg_output)
                    elif s == (len(self.stages) - 1):
                        seg_output = self.seg_layers[-1](x)
                        seg_outputs.append(seg_output)
            else:

                if self.deep_supervision:
                    seg_output = self.seg_layers[s](x)
                    seg_outputs.append(seg_output)
                elif s == (len(self.stages) - 1):
                    seg_output = self.seg_layers[-1](x)
                    seg_outputs.append(seg_output)
                
            lres_input = x
            
        seg_outputs = seg_outputs[::-1]

        if not self.deep_supervision:
            s = seg_outputs[0]
        else:
            s = seg_outputs
        return s, loss_graph_mean_list

    def compute_conv_feature_map_size(self, input_size):
        """
        IMPORTANT: input_size is the input_size of the encoder!
        :param input_size:
        :return:
        """
        # first we need to compute the skip sizes. Skip bottleneck because all output feature maps of our ops will at
        # least have the size of the skip above that (therefore -1)
        skip_sizes = []
        for s in range(len(self.encoder.strides) - 1):
            skip_sizes.append([i // j for i, j in zip(input_size, self.encoder.strides[s])])
            input_size = skip_sizes[-1]
        # print(skip_sizes)

        assert len(skip_sizes) == len(self.stages)

        # our ops are the other way around, so let's match things up
        output = np.int64(0)
        for s in range(len(self.stages)):
            # print(skip_sizes[-(s+1)], self.encoder.output_channels[-(s+2)])
            # conv blocks
            output += self.stages[s].compute_conv_feature_map_size(skip_sizes[-(s+1)])
            # trans conv
            output += np.prod([self.encoder.output_channels[-(s+2)], *skip_sizes[-(s+1)]], dtype=np.int64)
            # segmentation
            if self.deep_supervision or (s == (len(self.stages) - 1)):
                output += np.prod([self.num_classes, *skip_sizes[-(s+1)]], dtype=np.int64)
        return output

class FFN(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act='relu', drop_path=0.0, conv_op=nn.Conv3d, norm_op=nn.BatchNorm3d, norm_op_kwargs=None):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Sequential(
            conv_op(in_features, hidden_features, 1, stride=1, padding=0),
            norm_op(hidden_features, **norm_op_kwargs),
        )
        self.act = act_layer(act)
        self.fc2 = nn.Sequential(
            conv_op(hidden_features, out_features, 1, stride=1, padding=0),
            norm_op(out_features, **norm_op_kwargs),
        )
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

    def forward(self, x):
        shortcut = x
        x = self.fc1(x)
        x = self.act(x)
        x = self.fc2(x)
        x = self.drop_path(x) + shortcut
        return x  # .reshape(B, C, N, 1)

class MRConv(nn.Module):
    """
    Max-Relative Graph Convolution (Paper: https://arxiv.org/abs/1904.03751) for dense data type
    """
    def __init__(self, in_channels, out_channels, act='relu', norm=None, bias=True, conv_op=nn.Conv3d, dropout_op=nn.Dropout3d):
        super(MRConv, self).__init__()
        self.conv_op = conv_op
        self.nn = BasicConv([in_channels*2, out_channels], act=act, norm=norm, bias=bias, drop=0., conv_op=conv_op, dropout_op=dropout_op)

    def forward(self, x, edge_index, y=None):
        x_i = batched_index_select(x, edge_index[1])
        if y is not None:
            x_j = batched_index_select(y, edge_index[0])
        else:
            x_j = batched_index_select(x, edge_index[0])
        x_j, _ = torch.max(x_j - x_i, -1, keepdim=True)
        b, c, n, _ = x.shape
        x = torch.cat([x.unsqueeze(2), x_j.unsqueeze(2)], dim=2).reshape(b, 2 * c, n, _)
        
        if self.conv_op == nn.Conv2d:
            pass
        elif self.conv_op == nn.Conv3d:
            x = torch.unsqueeze(x, dim=4) 
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)
    
        return self.nn(x)

class MRConv_VesslGraph(nn.Module):
    """
    Max-Relative Graph Convolution (Paper: https://arxiv.org/abs/1904.03751) for dense data type
    """
    def __init__(self, in_channels, out_channels, act='relu', norm=None, bias=True, conv_op=nn.Conv3d, dropout_op=nn.Dropout3d):
        super(MRConv_VesslGraph, self).__init__()
        self.conv_op = conv_op
        self.nn = BasicConv([in_channels*2, out_channels], act=act, norm=norm, bias=bias, drop=0., conv_op=conv_op, dropout_op=dropout_op)
        self.mse_loss = nn.MSELoss(reduction='mean')

    def forward(self, x, edge_index, vessel_graph_edge_index, y=None):

        x_i = batched_index_select(x, edge_index[1])
        if y is not None:
            x_j = batched_index_select(y, edge_index[0])
        else:
            x_j = batched_index_select(x, edge_index[0])

        x_j_max, _ = torch.max(x_j - x_i, -1, keepdim=True)
        b, c, n, _ = x.shape
        x_cat = torch.cat([x.unsqueeze(2), x_j_max.unsqueeze(2)], dim=2).reshape(b, 2 * c, n, _)
        
        if self.conv_op == nn.Conv2d:
            pass
        elif self.conv_op == nn.Conv3d:
            x_cat = torch.unsqueeze(x_cat, dim=4) 
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)
        
        # vessel graph:
        x_vg_i = batched_index_select(x, vessel_graph_edge_index[1])
        if y is not None:
            x_vg_j = batched_index_select(y, vessel_graph_edge_index[0])
        else:
            x_vg_j = batched_index_select(x, vessel_graph_edge_index[0])
        
        # mse_loss = self.mse_loss(x_j, x_vg_j.detach())
            
        x_vg_j_max, _ = torch.max(x_vg_j - x_vg_i, -1, keepdim=True)

        b, c, n, _ = x.shape
        x_vg_cat = torch.cat([x.unsqueeze(2), x_vg_j_max.unsqueeze(2)], dim=2).reshape(b, 2 * c, n, _)
        
        if self.conv_op == nn.Conv2d:
            pass
        elif self.conv_op == nn.Conv3d:
            x_vg_cat = torch.unsqueeze(x_vg_cat, dim=4) 
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)

        mse_loss = self.mse_loss(x_cat, x_vg_cat.detach())
        
        return self.nn(x_cat), mse_loss

class GraphConv(nn.Module):
    """
    Static graph convolution layer
    """
    def __init__(self, in_channels, out_channels, conv='edge', act='relu', norm=None, bias=True, conv_op=nn.Conv3d, dropout_op=nn.Dropout3d):
        super(GraphConv, self).__init__()
        if conv == 'mr':
            self.gconv = MRConv(in_channels, out_channels, act, norm, bias, conv_op, dropout_op)
        else:
            raise NotImplementedError('conv:{} is not supported'.format(conv))

    def forward(self, x, edge_index, y=None):
        return self.gconv(x, edge_index, y)

class GraphConv_VesselGraph(nn.Module):
    """
    Static graph convolution layer
    """
    def __init__(self, in_channels, out_channels, conv='edge', act='relu', norm=None, bias=True, conv_op=nn.Conv3d, dropout_op=nn.Dropout3d):
        super(GraphConv_VesselGraph, self).__init__()
        if conv == 'mr_vg':
            self.gconv_vg = MRConv_VesslGraph(in_channels, out_channels, act, norm, bias, conv_op, dropout_op)
        else:
            raise NotImplementedError('conv:{} is not supported'.format(conv))

    def forward(self, x, edge_index, vessel_graph_edge_index, y=None):
        return self.gconv_vg(x, edge_index, vessel_graph_edge_index, y)

class DilateMask(nn.Module):
    """
    Dilate mask
    """
    def __init__(self, dilation_factor=3, conv_op=nn.Conv3d):
        super(DilateMask, self).__init__()
        padding = (dilation_factor - 1) // 2
        if conv_op == nn.Conv2d:
            self.conv_op = nn.Conv2d(1, 1, kernel_size=dilation_factor, stride=1, padding=padding, bias=True)
        elif conv_op == nn.Conv3d:
            self.conv_op = nn.Conv3d(1, 1, kernel_size=dilation_factor, stride=1, padding=padding, bias=True)
        else:
            raise NotImplementedError('conv operation [%s] is not found' % conv_op)

    def forward(self, mask):
        dilated_mask = self.conv_op(mask.float())
        return dilated_mask

def sample_outside_region(tensor_a, tensor_b, sampling_rate=0.3):
    """
    Sample the region outside of tensor A from tensor B.

    Args:
        tensor_a: Tensor A
        tensor_b: Tensor B
        sampling_rate: Sampling rate, ranging from 0 to 1

    Returns:
        Sampled result
    """
    # Create a mask with the same shape as tensor B, initialized to True
    sampling_mask = torch.ones_like(tensor_b, dtype=torch.bool)

    # Find the indices of tensor A
    a_indices = tensor_a.nonzero(as_tuple=True)

    # Set the mask values to False for the indices of tensor A
    sampling_mask[a_indices] = False

    # Calculate the number of samples to be taken
    num_samples = int(sampling_rate * sampling_mask.numel())

    # Randomly set the corresponding mask values to False for the sampled indices
    sampled_indices = torch.randperm(sampling_mask.numel())[:num_samples]
    sampling_mask.view(-1)[sampled_indices] = False

    # Apply the sampling mask to tensor B
    sampled_result = torch.logical_and(tensor_b, sampling_mask)

    return sampled_result

def adjacency_to_degree(tensor, max_degree=8):
    B, N, _ = tensor.shape
    indices = torch.arange(N, device=tensor.device).view(1, 1, -1).expand(B, N, N)
    tensor_2N = 2*N*torch.ones_like(tensor).to(tensor.device)
    tensor = torch.where(tensor > 0, indices, tensor_2N)

    index_tensor_12 = indices.transpose(1, 2)
    dist_tensor = torch.where(tensor == tensor_2N, tensor_2N, torch.abs((index_tensor_12 - tensor)))

    top_k_order, top_k_index = torch.topk(dist_tensor, max_degree, dim=-1, largest=False)
    top_k_order_2N = 2*N*torch.ones_like(top_k_order).to(top_k_order.device)
    degree_matrix = torch.where(top_k_order == top_k_order_2N, index_tensor_12[:, :, :max_degree], top_k_index)
    top_k_order_b0 = -N * torch.ones_like(top_k_order).to(top_k_order.device).long()
    degree_matrix_b0 = torch.where(top_k_order == top_k_order_2N, top_k_order_b0, top_k_index)

    return degree_matrix, degree_matrix_b0

def batch_id2pos_indexs(id, size):
    x, y, z = size

    pos_x = id // (y * z)
    pos_y = (id // z) % y
    pos_z = id % z

    pos = torch.stack((pos_x, pos_y, pos_z), dim=-1) # B, N, 3

    return pos

def batch_id2pos_indexs_tuple(id, size):
    x, y, z = size
    return (id // (y*z), (id // z) % y, id % z)

def batch_id2pos_indexs_np(id, size):
    x, y, z = size

    pos_x = (id // (y * z)).astype(np.int32)
    pos_y = ((id // z) % y).astype(np.int32)
    pos_z = (id % z).astype(np.int32)

    pos = np.stack((pos_x, pos_y, pos_z))

    return pos

def get_resample_pos_list(pos_list, scale_list):
    return np.ceil((pos_list + 1) / scale_list).astype(np.int32) - 1 if len(pos_list) != 0 else np.array([])

def batch_windows_pos_indexs(pos, window_size):
    pos_x, pos_y, pos_z = pos

    window_size_x, window_size_y, window_size_z = window_size

    window_ids_x = pos_x // window_size_x
    window_ids_y = pos_y // window_size_y
    window_ids_z = pos_z // window_size_z

    w_i_x = pos_x % window_size_x
    w_i_y = pos_y % window_size_y
    w_i_z = pos_z % window_size_z

    return np.stack((window_ids_x, window_ids_y, window_ids_z), axis=-1), np.stack((w_i_x, w_i_y, w_i_z), axis=-1)

def get_negative_positive_ratio(epoch, alpha, max_epoch=1000, max_ratio=100):
    # negative_positive_ratio = min(15 + max_ratio * 0.75 * ((epoch + 1) / (max_epoch + 1)) ** alpha, max_ratio * 0.8)
    negative_positive_ratio = min(1 + max_ratio * 0.75 * ((epoch + 1) / (max_epoch + 1)) ** alpha, max_ratio * 0.8)
    return negative_positive_ratio

def set_topk_adjacency_matrix(matrix, K):
    _, topk_indices = torch.topk(matrix, K, dim=2)
    mask = torch.zeros_like(matrix).to(matrix.device).float()
    mask.scatter_(2, topk_indices, torch.ones_like(mask).to(matrix.device).float())
    mask_t = mask.transpose(1, 2)
    # mask = torch.max(mask, mask_t).float()
    mask_1_0 = torch.min(mask, mask_t).float()
    mask_0_1 = torch.ones_like(mask).to(matrix.device).float() - mask_1_0
    return mask_1_0, mask_0_1

def reshape_and_reindex_tensor(windows_degree_tensor, Batch, window_size, num_windows):
    w_x, w_y, w_z = window_size
    n_x, n_y, n_z = num_windows
    x, y, z = w_x * n_x, w_y * n_y, w_z * n_z
    N = w_x * w_y * w_z
    B_nW, _, K = windows_degree_tensor.shape
    nW = B_nW // Batch
    windows_degree_tensor = windows_degree_tensor.reshape(Batch, nW, N, K)
    index_map = torch.zeros_like(windows_degree_tensor).to(windows_degree_tensor.device)
    
    windows_pos = torch.nonzero(windows_degree_tensor >= 0, as_tuple=False)
    window_ids = windows_pos[:, 1]
    window_ids_x = window_ids // (n_y * n_z)
    window_ids_y = (window_ids % (n_y * n_z)) // n_z
    window_ids_z = window_ids % n_z

    window_pos_id = windows_degree_tensor[windows_degree_tensor >= 0]

    w_i_x = window_pos_id // (w_y * w_z)
    w_i_y = (window_pos_id % (w_y * w_z)) // w_z
    w_i_z = window_pos_id % w_z
    
    pos_x = window_ids_x * w_x + w_i_x
    pos_y = window_ids_y * w_y + w_i_y
    pos_z = window_ids_z * w_z + w_i_z

    windows_nodes_pos = torch.nonzero(windows_degree_tensor >= 0, as_tuple=False)
    for i in range(0, windows_nodes_pos.shape[0]):
        b_i = windows_nodes_pos[i, 0]
        w_i = windows_nodes_pos[i, 1]
        k_i = windows_nodes_pos[i, 3]
        index_map[b_i, w_i, windows_nodes_pos[i, 2], k_i] = pos_x[i] * y * z + pos_y[i] * z + pos_z[i]
    
    windows_degree_tensor = torch.where(windows_degree_tensor >= 0, index_map, windows_degree_tensor)
    degree_tensor = windows_degree_tensor.reshape(Batch, n_x, n_y, n_z, w_x, w_y, w_z, K).permute(0, 1, 4, 2, 5, 3, 6, 7).reshape(Batch, n_x * w_x * n_y * w_y * n_z * w_z, K)
    
    return degree_tensor

def get_3d_coordinates(indices, shape):
    z = indices // (shape[0] * shape[1])
    y = (indices % (shape[0] * shape[1])) // shape[0]
    x = indices % shape[0]
    return torch.stack((x, y, z), dim=-1)

def process_window(w_i, mask_bool_1_b_i, mask_bool_0_b_i, windows_graph_edges_target_b_i, graph_output_split):
    mask_bool_0_b_i_pos = torch.nonzero(mask_bool_0_b_i[w_i], as_tuple=False)
    pre_nodes_indexs = (graph_output_split[w_i].permute(1, 0) * mask_bool_0_b_i_pos).flatten()
    pre_nodes_indexs = pre_nodes_indexs[pre_nodes_indexs != 0]

    mask_bool_pre_1 = torch.zeros_like(mask_bool_1_b_i[w_i]).squeeze(1).scatter(0, pre_nodes_indexs, 1).unsqueeze(1)

    indices = torch.nonzero(mask_bool_pre_1, as_tuple=True)[0]
    indices_neg = torch.nonzero(~mask_bool_pre_1, as_tuple=True)[0]
    indices_neg_select = torch.randperm(indices_neg.numel())[:indices.numel()]
    indices = torch.cat((indices, indices_neg[indices_neg_select]), dim=0)

    S = indices.shape[0]
    S_adj_matrix = torch.ones((S, S), dtype=torch.bool)
    edge_indexs = S_adj_matrix.nonzero(as_tuple=False)
    src_edge, dst_edge = edge_indexs[:, 0], edge_indexs[:, 1]

    temp_tensor = windows_graph_edges_target_b_i[w_i][indices]
    non_zero_rows_mask = temp_tensor.any(dim=1)
    non_zero_rows = temp_tensor[non_zero_rows_mask]
    non_zero_rows -= 1

    idx_result_list = []

    indices_dict = {v.item(): k for k, v in enumerate(indices)}

    for row in non_zero_rows:
        first_element = row[0]
        non_zero_elements = row[row != -1]

        for non_zero in non_zero_elements:
            if first_element.item() in indices_dict and non_zero.item() in indices_dict:
                idx_result_list.append([indices_dict[first_element.item()], indices_dict[non_zero.item()]])

    idx_result_set = set(tuple(x) for x in idx_result_list)
    edge_labels = torch.tensor([1 if (src_edge[e_i].item(), dst_edge[e_i].item()) in idx_result_set else 0 for e_i in range(src_edge.shape[0])])

    return edge_labels, src_edge, dst_edge, indices

def compute_euclidean_distance_map(segmentation, centerline):
	seg = segmentation.astype(np.bool)
	cen = centerline.astype(np.bool)
	map = ndimage.distance_transform_edt(np.logical_not(cen))

	map_max = np.max(map[seg > 0])
	map /= map_max
	map[seg == 0] = 1
	map = np.log2(map, out=np.zeros_like(map), where=(map!=0))
	map_min = np.min(map)
	map[cen>0] = map_min
	map -= np.min(map)
	map /= np.max(map)

	return map


def compute_normal_direction(centerline):
    # Compute the tangent direction at each point in the centerline
    tangents = (np.roll(centerline, -1, axis=0) - np.roll(centerline, 1, axis=0))[:-2]
    
    tangents = tangents.astype(np.float32)

    # Normalize the tangents
    tangents /= np.linalg.norm(tangents, axis=-1, keepdims=True)

    # Compute the normal direction by taking cross product of tangents with Z-axis
    normals = np.cross(tangents, np.array([0, 0, 1]))

    # Normalize the normals
    normals /= np.linalg.norm(normals, axis=-1, keepdims=True)
   
    return normals

def get_local_region(segmentation, centerline_point, normal_direction, size):
    # Create a grid of indices in the local region
    grid = np.indices([size, size, size]) - size // 2
   
    # Create a rotation matrix to align the Z-axis with the normal direction
    z_axis = np.array([0, 0, 1])
    if (normal_direction == z_axis).all():
        rotation_matrix = np.eye(3)
    else:
        v = np.cross(z_axis, normal_direction)
        c = np.dot(z_axis, normal_direction)
        s = np.linalg.norm(v)
        I = np.eye(3)

        # Cross product matrix
        v_x = np.array([
            [0, -v[2], v[1]],
            [v[2], 0, -v[0]],
            [-v[1], v[0], 0]
        ])

        # Rotation matrix
        rotation_matrix = I + v_x + np.dot(v_x, v_x) * ((1 - c) / (s ** 2))

    # Rotate the grid
    rotated_grid = rotation_matrix @ grid.reshape((3, -1))
    rotated_grid = rotated_grid.reshape((3, size, size, size))

    # Shift the rotated grid to the centerline point
    shifted_grid = rotated_grid + np.array(centerline_point)[:, None, None, None]
   
    # Interpolate the segmentation at the grid points
    local_region = ndimage.map_coordinates(segmentation, shifted_grid, order=1, mode='nearest')
   
    return local_region

def compute_local_distance_map(segmentation, cen_l, size):
    centerline = np.transpose(np.stack(np.where(cen_l == 1)))

    normals = compute_normal_direction(centerline)
    delta = 1e-6 # A small positive constant to avoid numerical issues
    original_shape = segmentation.shape

    distance_map_full = np.zeros(original_shape) + np.inf
    local_map_full = np.zeros(original_shape)

    for centerline_point, normal_direction in zip(centerline, normals):
        local_region = get_local_region(segmentation, centerline_point, normal_direction, size)
        distance_map = ndimage.distance_transform_edt(1 - local_region)
        local_map = distance_map + delta #np.log(distance_map + delta) # apply log-transform
        local_map -= local_map.min()
        local_map /= local_map.max()

        x, y, z = np.mgrid[0:size, 0:size, 0:size]
        x = x - size // 2 + centerline_point[0]
        y = y - size // 2 + centerline_point[1]
        z = z - size // 2 + centerline_point[2]
        
        # Clip the indices to the valid range
        x = np.clip(x, 0, original_shape[0]-1)
        y = np.clip(y, 0, original_shape[1]-1)
        z = np.clip(z, 0, original_shape[2]-1)
        
        indices = np.vstack((x.flatten(), y.flatten(), z.flatten())).T

        local_map_full[indices[:, 0], indices[:, 1], indices[:, 2]] = np.where(distance_map_full[indices[:, 0], indices[:, 1], indices[:, 2]] > distance_map.flatten(), local_map.flatten(), local_map_full[indices[:, 0], indices[:, 1], indices[:, 2]])
        distance_map_full[indices[:, 0], indices[:, 1], indices[:, 2]] = np.minimum(distance_map_full[indices[:, 0], indices[:, 1], indices[:, 2]], distance_map.flatten())

    return local_map_full

# def normalize_segment_adaptive(segment, centerline):
#     distance_transform_vol = distance_transform_edt(np.logical_not(segment == 0))
#     centerline_distance_transform_vol = distance_transform_edt(np.logical_not(centerline))
#     normalized_segment = np.zeros(segment.shape)
#     centerline_points = np.array(np.where(centerline == 1)).T
#     for point in centerline_points:
#         x, y, z = point
#         radius = distance_transform_vol[x, y, z]
#         radius_int = int(np.round(radius))
#         bounding_cube = cube(2*radius_int+1)
#         x_start = max(0, x - radius_int)
#         x_end = min(segment.shape[0], x + radius_int + 1)
#         y_start = max(0, y - radius_int)
#         y_end = min(segment.shape[1], y + radius_int + 1)
#         z_start = max(0, z - radius_int)
#         z_end = min(segment.shape[2], z + radius_int + 1)
#         region = centerline_distance_transform_vol[x_start:x_end, y_start:y_end, z_start:z_end]
#         region_mask = region * bounding_cube[0:x_end-x_start, 0:y_end-y_start, 0:z_end-z_start] * segment[x_start:x_end, y_start:y_end, z_start:z_end]
#         max_dist = region_mask.max()
#         normalized_segment[x_start:x_end, y_start:y_end, z_start:z_end][segment[x_start:x_end, y_start:y_end, z_start:z_end] == 1] = np.maximum(
#             normalized_segment[x_start:x_end, y_start:y_end, z_start:z_end][segment[x_start:x_end, y_start:y_end, z_start:z_end] == 1],
#             region_mask[segment[x_start:x_end, y_start:y_end, z_start:z_end] == 1] / max_dist if max_dist > 0 else region_mask[segment[x_start:x_end, y_start:y_end, z_start:z_end] == 1]
#         )
#     return normalized_segment

def normalize_segment_adaptive(segment, centerline):
    distance_transform_vol = distance_transform_edt(np.logical_not(segment == 0))
    # centerline_distance_transform_vol = distance_transform_edt(np.logical_not(centerline))
    normalized_segment = np.zeros(segment.shape)
    processed_mask = np.zeros(segment.shape, dtype=bool)
    centerline_points = np.array(np.where(centerline == 1)).T
    for point in centerline_points:
        x, y, z = point
        radius = distance_transform_vol[x, y, z]
        radius_int = int(np.round(radius))
        bounding_cube = cube(2*radius_int+1)
        x_start = max(0, x - radius_int)
        x_end = min(segment.shape[0], x + radius_int + 1)
        y_start = max(0, y - radius_int)
        y_end = min(segment.shape[1], y + radius_int + 1)
        z_start = max(0, z - radius_int)
        z_end = min(segment.shape[2], z + radius_int + 1)
        region = distance_transform_vol[x_start:x_end, y_start:y_end, z_start:z_end]
        region_mask = region * bounding_cube[0:x_end-x_start, 0:y_end-y_start, 0:z_end-z_start] * segment[x_start:x_end, y_start:y_end, z_start:z_end]
        max_dist = region_mask.max()
        normalized_segment[x_start:x_end, y_start:y_end, z_start:z_end][segment[x_start:x_end, y_start:y_end, z_start:z_end] == 1] = np.maximum(
            normalized_segment[x_start:x_end, y_start:y_end, z_start:z_end][segment[x_start:x_end, y_start:y_end, z_start:z_end] == 1],
            region_mask[segment[x_start:x_end, y_start:y_end, z_start:z_end] == 1] / max_dist if max_dist > 0 else region_mask[segment[x_start:x_end, y_start:y_end, z_start:z_end] == 1]
        )
        processed_mask[x_start:x_end, y_start:y_end, z_start:z_end][segment[x_start:x_end, y_start:y_end, z_start:z_end] == 1] = True

    normalized_segment[~processed_mask] = 0
    return normalized_segment

def create_graph_from_centerline(centerline, num_neighbors):
    # 检查样本数是否大于邻居数
    if len(centerline) < num_neighbors:
        print("Insufficient samples. Need at least as many samples as neighbors.")
        return None

    # 使用 KNN 找到每个节点的相邻节点
    nbrs = NearestNeighbors(n_neighbors=num_neighbors, algorithm='ball_tree').fit(centerline)
    distances, indices = nbrs.kneighbors(centerline)

    # 创建一个空的图
    G = nx.Graph()

    # 为每个节点添加一个节点
    for i in range(len(centerline)):
        G.add_node(i, pos=centerline[i])

    # 预计算所有的边
    edges = [(i, indices[i, j], distances[i, j]) for i in range(len(centerline)) for j in range(1, num_neighbors)]

    # 一次性添加所有的边
    G.add_weighted_edges_from(edges)

    # 计算 Minimum Spanning Tree
    T = nx.minimum_spanning_tree(G, algorithm="kruskal", weight="weight")

    return T

class DyGraphConv(GraphConv): #(GraphConv_VesselGraph)
    """
    Dynamic graph convolution layer
    """
    def __init__(self, in_channels, out_channels, kernel_size=9, dilation=1, conv='edge', act='relu',
                 norm=None, bias=True, stochastic=False, epsilon=0.0, r=1, conv_op=nn.Conv3d, dropout_op=nn.Dropout3d):
        super(DyGraphConv, self).__init__(in_channels, out_channels, conv, act, norm, bias, conv_op, dropout_op)
        self.k = kernel_size
        self.d = dilation
        self.r = r
        self.dilated_knn_graph = DenseDilatedKnnGraph(kernel_size, dilation, stochastic, epsilon)
        # self.dilated_knn_graph_train = DenseDilatedKnnGraph_Train(kernel_size, dilation, stochastic, epsilon)
        # self.dilated_knn_graph_with_mask = DenseDilatedKnnGraph_With_Mask(kernel_size, dilation, stochastic, epsilon)
        self.conv_op = conv_op
        self.dropout_op = dropout_op
        if self.conv_op == nn.Conv2d:
            self.avg_pool = F.avg_pool2d
        elif self.conv_op == nn.Conv3d:
            self.avg_pool = F.avg_pool3d
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)
        
        self.mse_loss = nn.MSELoss(reduction='mean')

        self.graph_predictor = GraphPredictor(in_channels)
        self.graph_edges_predictor = GraphEdgesPredictor(in_channels)

        self.graph_node_loss = DC_and_CE_loss({'batch_dice': True,
                                   'smooth': 1e-5, 'do_bg': False, 'ddp': False}, {}, weight_ce=1, weight_dice=1,
                                  ignore_label=None, dice_class=MemoryEfficientSoftDiceLoss)

        self.alpha = 0.9

    def forward(self, x, relative_pos=None, windows_seg_target=None, windows_graph_edges_target=None, windows_graph_nodes=None, img_shape=None, current_epoch=None, m2g2m=True, val_flag=False, test_flag=True):
        if self.conv_op == nn.Conv2d:
            B, C, H, W = x.shape
        elif self.conv_op == nn.Conv3d:
            B, C, H, W, D = x.shape
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)

        y = None
        if self.r > 1:
            y = self.avg_pool(x, self.r, self.r)
            y = y.reshape(B, C, -1, 1).contiguous()            
        x = x.reshape(B, C, -1, 1).contiguous()

        self.f_shape = img_shape
        device = x.device
        
        if m2g2m == True:
            if test_flag == False:
                Batch = B
                N = H * W * D

                feature_map_windows = x.reshape(Batch, C, H, W, D)

                target_save_np = windows_graph_nodes.detach().cpu().numpy()

                windows_seg_target_save_np = windows_seg_target.squeeze(1).detach().cpu().numpy()

                seg_node_3d_np = np.where(target_save_np == 1, 2, 0)
                seg_node_3d_np = np.where(seg_node_3d_np == 2, 2, windows_seg_target_save_np)
                dist_map_3d_np = seg_node_3d_np

                seg_dist_map_3d_np = np.where(windows_seg_target_save_np == 0, -0.5, dist_map_3d_np)

                seg_node_3d = torch.from_numpy(seg_node_3d_np).to(device).unsqueeze(1).float()

                pre_results = self.graph_predictor(feature_map_windows) #
                seg_results = pre_results

                loss_graph_nodes_mean = self.graph_node_loss(seg_results, seg_node_3d.detach())
                seg_results_prob = torch.softmax(seg_results, 1)

                seg_pre = torch.argmax(seg_results_prob, dim=1)
                skel_pred = torch.where(seg_pre == 2, 1, 0).squeeze(1)
                skel_true = torch.where(seg_node_3d.detach() == 2, 1, 0).squeeze(1)
                y_pred = torch.where(seg_pre > 0, 1, 0).squeeze(1)
                y_true = torch.where(seg_node_3d.detach() > 0, 1, 0).squeeze(1)

                self.smooth = 1.

                tprec = (torch.sum(torch.multiply(skel_pred, y_true))+self.smooth)/(torch.sum(skel_pred)+self.smooth)    
                tsens = (torch.sum(torch.multiply(skel_true, y_pred))+self.smooth)/(torch.sum(skel_true)+self.smooth)    
                cl_dice = 1.- 2.0*(tprec*tsens)/(tprec+tsens)
                print("cl_dice: ", cl_dice)

                loss_density = torch.abs(skel_pred.sum() - skel_true.sum()) / skel_true.numel()
                d_alpha = 2e4 #6e3 #3e3
                print("loss_density * d_alpha: ", loss_density * d_alpha)

                print("loss_graph_nodes_mean: ", loss_graph_nodes_mean)
                loss_graph_nodes_mean = loss_graph_nodes_mean + cl_dice + loss_density * d_alpha

                Batch, d, w, h = skel_pred.shape
                
                # if current_epoch >= 0:
                self.max_degree = 7
                self.windows_graph_degree_tensor_dict = {}
                self.stage_shape_list = np.array([[64, 192, 192], [32, 96, 96], [16, 48, 48], [8, 24, 24], [4, 12, 12]]) #np.array([[64, 224, 224], [32, 112, 112], [16, 56, 56], [8, 28, 28], [4, 14, 14]]) #np.array([[40, 128, 128], [20, 64, 64], [10, 32, 32], [5, 16, 16]])
                for b_i in range(0, Batch):
                    skel_pred_np = skel_pred[b_i].detach().cpu().numpy()
                    raw_shape = np.array(skel_pred_np.shape)
                    nodes_np = np.array(np.nonzero(skel_pred_np)).transpose(1, 0)

                    nodes_pos_np = nodes_np
                    pos_list = nodes_pos_np

                    if current_epoch == 0:
                        bidirectional_edges_list = []
                    else:
                        G = create_graph_from_centerline(nodes_pos_np, 5) # num_neighbors = 5
                        if G == None:
                            new_edges_list = []
                        else:
                            new_edges_list = [list(edge) for edge in G.edges]

                        new_edges_reverse_list = [edge[::-1] for edge in new_edges_list]
                        bidirectional_edges_list = new_edges_list + new_edges_reverse_list

                    for s in [0]:
                        new_shape = np.array(self.stage_shape_list[s])
                        scale_list = raw_shape // new_shape
                        resample_pos_list = get_resample_pos_list(np.array(pos_list), scale_list)
                        resample_points_data_3D_degree = np.zeros((self.max_degree + 1,) + tuple(new_shape))

                        resample_points_data_3D_degree_dict = {}
                        for edge in bidirectional_edges_list:
                            node1 = edge[0]
                            node1_index = new_shape[1] * new_shape[2] * resample_pos_list[node1][0] + new_shape[2] * resample_pos_list[node1][1] + resample_pos_list[node1][2]
                            resample_points_data_3D_degree_dict.setdefault(node1_index, set())

                            if not resample_points_data_3D_degree[0, resample_pos_list[node1][0], resample_pos_list[node1][1], resample_pos_list[node1][2]]:
                                resample_points_data_3D_degree[0, resample_pos_list[node1][0], resample_pos_list[node1][1], resample_pos_list[node1][2]] = node1_index
                                resample_points_data_3D_degree_dict[node1_index].add(node1_index)

                            node2 = edge[1]
                            node2_index = new_shape[1] * new_shape[2] * resample_pos_list[node2][0] + new_shape[2] * resample_pos_list[node2][1] + resample_pos_list[node2][2]

                            for d in range(1, self.max_degree + 1):
                                if resample_points_data_3D_degree[d, resample_pos_list[node1][0], resample_pos_list[node1][1], resample_pos_list[node1][2]] == 0 and node2_index not in resample_points_data_3D_degree_dict[node1_index]:
                                    resample_points_data_3D_degree[d, resample_pos_list[node1][0], resample_pos_list[node1][1], resample_pos_list[node1][2]] = node2_index
                                    resample_points_data_3D_degree_dict[node1_index].add(node2_index)
                                    break
                        
                        windows_graph_degree = resample_points_data_3D_degree
                    
                        if s not in self.windows_graph_degree_tensor_dict:
                            self.windows_graph_degree_tensor_dict[s] = []
                        else:
                            pass
                        self.windows_graph_degree_tensor_dict[s].append(windows_graph_degree)
                
                for stage in self.windows_graph_degree_tensor_dict:
                    windows_graph_degree_stage_tensor = torch.tensor(np.array(self.windows_graph_degree_tensor_dict[stage], dtype=np.float32)).float()
                    self.windows_graph_degree_tensor_dict[stage] = windows_graph_degree_stage_tensor
                
                windows_graph_edges_target_dict = {}
                for s in [0]:
                    tensor = self.windows_graph_degree_tensor_dict[s] #.permute(0, 2, 1, 3, 4, 5)
                    B, nD, H, W, D = tensor.shape
                    new_shape = [B, nD, H * W * D]
                    tensor = tensor.reshape(*new_shape).long()
                    windows_graph_edges_target_dict[s] = tensor.permute(0, 2, 1)

                s = 0
                windows_graph_edges_target = windows_graph_edges_target_dict[s]
                windows_graph_edges_target = windows_graph_edges_target.reshape(B, N, self.k).to(device)
                windows_degree_tensor_pre_b0 = -N*torch.ones_like(windows_graph_edges_target).to(device)

                graph_results = torch.argmax(seg_results_prob, dim=1)
                graph_results_np = graph_results.detach().cpu().squeeze(1).numpy().astype(np.float32)

                # windows_graph_nodes_pre = torch.where(graph_results == 2, 1, 0).squeeze(1).reshape(Batch, num_windows[0], w_x, num_windows[1], w_y, num_windows[2], w_z).permute(0, 1, 3, 5, 2, 4, 6).reshape(B_nW, N)

                if val_flag:
                    self.output_folder = "/media/hitlab/ssd_2/spc/Dataset/nnUNet/nnUNet_results/Dataset990_angio_MRA_test/nnUNetTrainer_NexToU_Plus__nnUNetPlans__3d_fullres/fold_0"
                    target_b_i_path = self.output_folder + "/dgc/dgc_epoch" + str(current_epoch) + "/target_b_2"
                    if os.path.exists(target_b_i_path):
                        shutil.rmtree(target_b_i_path)
                    maybe_mkdir_p(target_b_i_path)
                    windows_seg_target_b_i_path = self.output_folder + "/dgc/dgc_epoch" + str(current_epoch) + "/windows_seg_target_b_2"
                    if os.path.exists(windows_seg_target_b_i_path):
                        shutil.rmtree(windows_seg_target_b_i_path)
                    maybe_mkdir_p(windows_seg_target_b_i_path)
                    target_dist_map_3d_path = self.output_folder + "/dgc/dgc_epoch" + str(current_epoch) + "/target_dist_map_3d"
                    if os.path.exists(target_dist_map_3d_path):
                        shutil.rmtree(target_dist_map_3d_path)
                    maybe_mkdir_p(target_dist_map_3d_path)
                    seg_dist_map_3d_path = self.output_folder + "/dgc/dgc_epoch" + str(current_epoch) + "/seg_dist_map_3d"
                    if os.path.exists(seg_dist_map_3d_path):
                        shutil.rmtree(seg_dist_map_3d_path)
                    maybe_mkdir_p(seg_dist_map_3d_path)
                    graph_results_np_path = self.output_folder + "/dgc/dgc_epoch" + str(current_epoch) + "/graph_results_np"
                    if os.path.exists(graph_results_np_path):
                        shutil.rmtree(graph_results_np_path)
                    maybe_mkdir_p(graph_results_np_path)
                    for b_i in range(0, Batch):
                        tmp_np = target_save_np[b_i]
                        nifti_data_img1 = nib.Nifti1Image(tmp_np, np.eye(4))
                        nib.save(nifti_data_img1, target_b_i_path + "/" + f'target_b_{b_i}.nii.gz')

                        tmp_np = windows_seg_target_save_np[b_i]
                        nifti_data_img1 = nib.Nifti1Image(tmp_np, np.eye(4))
                        nib.save(nifti_data_img1, windows_seg_target_b_i_path + "/" + f'windows_seg_target_b_{b_i}_w.nii.gz')
    
                        tmp_np = dist_map_3d_np[b_i]
                        nifti_data_img1 = nib.Nifti1Image(tmp_np, np.eye(4))
                        nib.save(nifti_data_img1, target_dist_map_3d_path + "/" + f'target_dist_map_3d_{b_i}.nii.gz')

                        tmp_np = seg_dist_map_3d_np[b_i]
                        nifti_data_img1 = nib.Nifti1Image(tmp_np, np.eye(4))
                        nib.save(nifti_data_img1, seg_dist_map_3d_path + "/" + f'seg_dist_map_3d_{b_i}.nii.gz')

                        tmp_np = graph_results_np[b_i]
                        nifti_data_img1 = nib.Nifti1Image(tmp_np, np.eye(4))
                        nib.save(nifti_data_img1, graph_results_np_path + "/" + f'graph_results_np_{b_i}.nii.gz')
                else:
                    pass

                windows_degree_tensor_pre_b0 = windows_degree_tensor_pre_b0
                windows_graph_edges_target = windows_graph_edges_target
                windows_N_k = torch.arange(N, device=windows_degree_tensor_pre_b0.device).view(1, -1, 1).expand(B, -1, self.k)
                windows_neg_N = -N * torch.ones_like(windows_N_k).to(windows_N_k.device)
                windows_degree_tensor_pre = torch.where(windows_degree_tensor_pre_b0 > 0, windows_degree_tensor_pre_b0, windows_N_k)
                windows_degree_tensor_target_b0 = torch.where(windows_graph_edges_target > 0, windows_graph_edges_target-1, windows_neg_N)
                with torch.no_grad():
                    # B_nW, N, K = windows_degree_tensor_target_b0.shape
                    degree_tensor_target = windows_degree_tensor_target_b0 #reshape_and_reindex_tensor(windows_degree_tensor_target_b0, B, self.window_size, num_windows)

                    degree_tensor_pre = windows_degree_tensor_pre_b0 #reshape_and_reindex_tensor(windows_degree_tensor_pre_b0, B, self.window_size, num_windows)

                loss_graph_mean = loss_graph_nodes_mean

                n_points = N #w_x * w_y * w_z
                center_idx = torch.arange(0, n_points, device=x.device).repeat(B, self.k, 1).transpose(2, 1)
            
                nn_idx = windows_degree_tensor_pre
                edge_index = torch.stack((nn_idx, center_idx), dim=0)

                if val_flag:
                    edge_index_dst, edge_index_src = edge_index[0], edge_index[1]
                    B_nW, shape_multi, k = edge_index_src.shape
                    self.output_folder = "/media/hitlab/ssd_2/spc/Dataset/nnUNet/nnUNet_results/Dataset990_angio_MRA_test/nnUNetTrainer_NexToU_Plus__nnUNetPlans__3d_fullres/fold_0"

                    d, h, w = self.f_shape[0], self.f_shape[1], self.f_shape[2]
                    Batch, N_L, K = degree_tensor_target.shape
                    degree_tensor_target_path = self.output_folder + "/dgc/dgc_epoch" + str(current_epoch) + "/dgc_degree_tensor_target" + "_" + str(Batch) + "_" + str(N_L) + "_" + str(K)
                    degree_tensor_target_np = degree_tensor_target.detach().cpu().numpy().reshape(Batch, d, h, w, K).transpose((0, 4, 1, 2, 3))
                    maybe_mkdir_p(degree_tensor_target_path)
                    for b_idx in range(Batch):
                        for k_idx in range(K):
                            tmp_np = degree_tensor_target_np[b_idx, k_idx]
                            nifti_data_img1 = nib.Nifti1Image(tmp_np, np.eye(4))
                            nib.save(nifti_data_img1, degree_tensor_target_path + "/" + f'degree_tensor_target_b_{b_idx}_k_{k_idx}_.nii.gz')
                    
                    degree_tensor_pre_path = self.output_folder + "/dgc/dgc_epoch" + str(current_epoch) + "/dgc_degree_tensor_pre" + "_" + str(Batch) + "_" + str(N_L) + "_" + str(K)
                    degree_tensor_pre_np = degree_tensor_pre.detach().cpu().numpy().reshape(Batch, d, h, w, K).transpose((0, 4, 1, 2, 3))
                    maybe_mkdir_p(degree_tensor_pre_path)
                    for b_idx in range(Batch):
                        for k_idx in range(K):
                            tmp_np = degree_tensor_pre_np[b_idx, k_idx]
                            nifti_data_img1 = nib.Nifti1Image(tmp_np, np.eye(4))
                            nib.save(nifti_data_img1, degree_tensor_pre_path + "/" + f'degree_tensor_pre_b_{b_idx}_k_{k_idx}_.nii.gz')
                else:
                    pass
                
                # else:
                #     loss_graph_mean = loss_graph_nodes_mean
                #     edge_index = self.dilated_knn_graph(x, y, relative_pos)
            else:
                Batch = B
                N = H * W * D

                feature_map_windows = x.reshape(Batch, C, H, W, D)

                # target_save_np = windows_graph_nodes.detach().cpu().numpy()

                # windows_seg_target_save_np = windows_seg_target.squeeze(1).detach().cpu().numpy()

                # seg_node_3d_np = np.where(target_save_np == 1, 2, 0)
                # seg_node_3d_np = np.where(seg_node_3d_np == 2, 2, windows_seg_target_save_np)
                # dist_map_3d_np = seg_node_3d_np

                # seg_dist_map_3d_np = np.where(windows_seg_target_save_np == 0, -0.5, dist_map_3d_np)

                # seg_node_3d = torch.from_numpy(seg_node_3d_np).to(device).unsqueeze(1).float()

                pre_results = self.graph_predictor(feature_map_windows) #
                seg_results = pre_results

                # loss_graph_nodes_mean = self.graph_node_loss(seg_results, seg_node_3d.detach())
                seg_results_prob = torch.softmax(seg_results, 1)
                
                seg_pre = torch.argmax(seg_results_prob, dim=1)
                skel_pred = torch.where(seg_pre == 2, 1, 0).squeeze(1)
                # skel_true = torch.where(seg_node_3d.detach() == 2, 1, 0).squeeze(1)
                # y_pred = torch.where(seg_pre > 0, 1, 0).squeeze(1)
                # y_true = torch.where(seg_node_3d.detach() > 0, 1, 0).squeeze(1)

                # self.smooth = 1.

                # tprec = (torch.sum(torch.multiply(skel_pred, y_true))+self.smooth)/(torch.sum(skel_pred)+self.smooth)    
                # tsens = (torch.sum(torch.multiply(skel_true, y_pred))+self.smooth)/(torch.sum(skel_true)+self.smooth)    
                # cl_dice = 1.- 2.0*(tprec*tsens)/(tprec+tsens)
                # print("cl_dice: ", cl_dice)

                # loss_density = torch.abs(skel_pred.sum() - skel_true.sum()) / skel_true.numel()
                # print("loss_density * 1e3: ", loss_density * 1e3)

                # print("loss_graph_nodes_mean: ", loss_graph_nodes_mean)
                # loss_graph_nodes_mean = loss_graph_nodes_mean + cl_dice + loss_density * 1e3

                Batch, d, w, h = skel_pred.shape
                
                self.max_degree = 7
                self.windows_graph_degree_tensor_dict = {}
                self.stage_shape_list = np.array([[64, 192, 192], [32, 96, 96], [16, 48, 48], [8, 24, 24], [4, 12, 12]]) #np.array([[64, 224, 224], [32, 112, 112], [16, 56, 56], [8, 28, 28], [4, 14, 14]]) #np.array([[40, 128, 128], [20, 64, 64], [10, 32, 32], [5, 16, 16]])
                for b_i in range(0, Batch):
                    skel_pred_np = skel_pred[b_i].detach().cpu().numpy()
                    raw_shape = np.array(skel_pred_np.shape)
                    nodes_np = np.array(np.nonzero(skel_pred_np)).transpose(1, 0)

                    nodes_pos_np = nodes_np
                    pos_list = nodes_pos_np

                    if current_epoch == 0:
                        bidirectional_edges_list = []
                    else:
                        G = create_graph_from_centerline(nodes_pos_np, 5) # num_neighbors = 5
                        if G == None:
                            new_edges_list = []
                        else:
                            new_edges_list = [list(edge) for edge in G.edges]

                        new_edges_reverse_list = [edge[::-1] for edge in new_edges_list]
                        bidirectional_edges_list = new_edges_list + new_edges_reverse_list

                    for s in [0]:
                        new_shape = np.array(self.stage_shape_list[s])
                        scale_list = raw_shape // new_shape
                        resample_pos_list = get_resample_pos_list(np.array(pos_list), scale_list)
                        resample_points_data_3D_degree = np.zeros((self.max_degree + 1,) + tuple(new_shape))

                        resample_points_data_3D_degree_dict = {}
                        for edge in bidirectional_edges_list:
                            node1 = edge[0]
                            node1_index = new_shape[1] * new_shape[2] * resample_pos_list[node1][0] + new_shape[2] * resample_pos_list[node1][1] + resample_pos_list[node1][2]
                            resample_points_data_3D_degree_dict.setdefault(node1_index, set())

                            if not resample_points_data_3D_degree[0, resample_pos_list[node1][0], resample_pos_list[node1][1], resample_pos_list[node1][2]]:
                                resample_points_data_3D_degree[0, resample_pos_list[node1][0], resample_pos_list[node1][1], resample_pos_list[node1][2]] = node1_index
                                resample_points_data_3D_degree_dict[node1_index].add(node1_index)

                            node2 = edge[1]
                            node2_index = new_shape[1] * new_shape[2] * resample_pos_list[node2][0] + new_shape[2] * resample_pos_list[node2][1] + resample_pos_list[node2][2]

                            for d in range(1, self.max_degree + 1):
                                if resample_points_data_3D_degree[d, resample_pos_list[node1][0], resample_pos_list[node1][1], resample_pos_list[node1][2]] == 0 and node2_index not in resample_points_data_3D_degree_dict[node1_index]:
                                    resample_points_data_3D_degree[d, resample_pos_list[node1][0], resample_pos_list[node1][1], resample_pos_list[node1][2]] = node2_index
                                    resample_points_data_3D_degree_dict[node1_index].add(node2_index)
                                    break
                        
                        windows_graph_degree = resample_points_data_3D_degree
                    
                        if s not in self.windows_graph_degree_tensor_dict:
                            self.windows_graph_degree_tensor_dict[s] = []
                        else:
                            pass
                        self.windows_graph_degree_tensor_dict[s].append(windows_graph_degree)
                
                for stage in self.windows_graph_degree_tensor_dict:
                    windows_graph_degree_stage_tensor = torch.tensor(np.array(self.windows_graph_degree_tensor_dict[stage], dtype=np.float32)).float()
                    self.windows_graph_degree_tensor_dict[stage] = windows_graph_degree_stage_tensor
                
                windows_graph_edges_target_dict = {}
                for s in [0]:
                    tensor = self.windows_graph_degree_tensor_dict[s]
                    B, nD, H, W, D = tensor.shape
                    new_shape = [B, nD, H * W * D]
                    tensor = tensor.reshape(*new_shape).long()
                    windows_graph_edges_target_dict[s] = tensor.permute(0, 2, 1)

                s = 0
                windows_graph_edges_target = windows_graph_edges_target_dict[s]
                windows_graph_edges_target = windows_graph_edges_target.reshape(B, N, self.k).to(device)
                windows_degree_tensor_pre_b0 = -N*torch.ones_like(windows_graph_edges_target).to(device)

                graph_results = torch.argmax(seg_results_prob, dim=1)
                graph_results_np = graph_results.detach().cpu().squeeze(1).numpy().astype(np.float32)

                windows_degree_tensor_pre_b0 = windows_degree_tensor_pre_b0
                windows_graph_edges_target = windows_graph_edges_target
                windows_N_k = torch.arange(N, device=windows_degree_tensor_pre_b0.device).view(1, -1, 1).expand(B, -1, self.k)
                windows_neg_N = -N * torch.ones_like(windows_N_k).to(windows_N_k.device)
                windows_degree_tensor_pre = torch.where(windows_degree_tensor_pre_b0 > 0, windows_degree_tensor_pre_b0, windows_N_k)
                windows_degree_tensor_target_b0 = torch.where(windows_graph_edges_target > 0, windows_graph_edges_target-1, windows_neg_N)
                with torch.no_grad():
                    degree_tensor_target = windows_degree_tensor_target_b0 

                    degree_tensor_pre = windows_degree_tensor_pre_b0

                # loss_graph_mean = loss_graph_nodes_mean
                loss_graph_mean = 0

                n_points = N
                center_idx = torch.arange(0, n_points, device=x.device).repeat(B, self.k, 1).transpose(2, 1)
            
                nn_idx = windows_degree_tensor_pre
                edge_index = torch.stack((nn_idx, center_idx), dim=0)

                edge_index_dst, edge_index_src = edge_index[0], edge_index[1]
                B, shape_multi, k = edge_index_src.shape
                
                x= super(DyGraphConv, self).forward(x, edge_index, y)

                if self.conv_op == nn.Conv2d:
                    return x.reshape(B, -1, H, W).contiguous(), loss_graph_mean, seg_results
                elif self.conv_op == nn.Conv3d:
                    return x.reshape(B, -1, H, W, D).contiguous(), loss_graph_mean, seg_results
                else:
                    raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)
                
        else:
            loss_graph_mean = 0
            nn_idx = 0
            edge_index = self.dilated_knn_graph(x, y, relative_pos)

        edge_index_dst, edge_index_src = edge_index[0], edge_index[1]
        B, shape_multi, k = edge_index_src.shape
        
        x= super(DyGraphConv, self).forward(x, edge_index, y)

        if self.conv_op == nn.Conv2d:
            return x.reshape(B, -1, H, W).contiguous(), loss_graph_mean
        elif self.conv_op == nn.Conv3d:
            return x.reshape(B, -1, H, W, D).contiguous(), loss_graph_mean
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)


class Raw_DyGraphConv(GraphConv):
    """
    Dynamic graph convolution layer
    """
    def __init__(self, in_channels, out_channels, kernel_size=9, dilation=1, conv='edge', act='relu',
                 norm=None, bias=True, stochastic=False, epsilon=0.0, r=1, conv_op=nn.Conv3d, dropout_op=nn.Dropout3d):
        super(Raw_DyGraphConv, self).__init__(in_channels, out_channels, conv, act, norm, bias, conv_op, dropout_op)
        self.k = kernel_size
        self.d = dilation
        self.r = r
        self.dilated_knn_graph = DenseDilatedKnnGraph(kernel_size, dilation, stochastic, epsilon)
        self.conv_op = conv_op
        self.dropout_op = dropout_op
        if self.conv_op == nn.Conv2d:
            self.avg_pool = F.avg_pool2d
        elif self.conv_op == nn.Conv3d:
            self.avg_pool = F.avg_pool3d
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)

    def forward(self, x, relative_pos=None):
        if self.conv_op == nn.Conv2d:
            B, C, H, W = x.shape
        elif self.conv_op == nn.Conv3d:
            B, C, H, W, D = x.shape
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)

        y = None
        if self.r > 1:
            y = self.avg_pool(x, self.r, self.r)
            y = y.reshape(B, C, -1, 1).contiguous()            
        x = x.reshape(B, C, -1, 1).contiguous()
        edge_index = self.dilated_knn_graph(x, y, relative_pos)
        x = super(Raw_DyGraphConv, self).forward(x, edge_index, y)
        if self.conv_op == nn.Conv2d:
            return x.reshape(B, -1, H, W).contiguous()
        elif self.conv_op == nn.Conv3d:
            return x.reshape(B, -1, H, W, D).contiguous()
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)

class PoolDyGraphConv(GraphConv):
    """
    Pool Dynamic graph convolution layer
    """
    def __init__(self, in_channels, out_channels, kernel_size=9, dilation=1, conv='edge', act='relu',
                 norm=None, bias=True, stochastic=False, epsilon=0.0, r=1, conv_op=nn.Conv3d, dropout_op=nn.Dropout3d, img_shape=None, img_min_shape=None):
        super(PoolDyGraphConv, self).__init__(in_channels, out_channels, conv, act, norm, bias, conv_op, dropout_op)
        self.k = kernel_size
        self.d = dilation
        self.r = r
        self.dilated_knn_graph = DenseDilatedKnnGraph(kernel_size, dilation, stochastic, epsilon)
        self.conv_op = conv_op
        self.dropout_op = dropout_op

        n = 1
        for h in img_shape:
            n = n * h
        
        n_small = 1
        for h_small in img_min_shape:
            n_small = n_small * h_small * 4

        if n > n_small:
            pool_size = [2 if h % 2 == 0 else 1 for h in img_shape]
        else:
            pool_size = [1 for h in img_shape]

        self.pool_size = pool_size
        
        if self.conv_op == nn.Conv2d:
            self.avg_pool = F.avg_pool2d
            self.max_pool_input = nn.MaxPool2d(pool_size, stride=pool_size, return_indices=True)
            self.max_unpool_output = nn.MaxUnpool2d(pool_size, stride=pool_size)
        elif self.conv_op == nn.Conv3d:
            self.avg_pool = F.avg_pool3d
            self.max_pool_input = nn.MaxPool3d(pool_size, stride=pool_size, return_indices=True)
            self.max_unpool_output = nn.MaxUnpool3d(pool_size, stride=pool_size)
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)

    def forward(self, x, relative_pos=None):
        if self.conv_op == nn.Conv2d:
            B, C, H, W = x.shape
        elif self.conv_op == nn.Conv3d:
            B, C, S, H, W = x.shape
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)

        x, indices = self.max_pool_input(x)   
        y = None
        if self.r > 1:
            y = self.avg_pool(x, self.r, self.r)
            y = y.reshape(B, C, -1, 1).contiguous()   

        x = x.reshape(B, C, -1, 1).contiguous()
        indices = indices.reshape(B, C, -1, 1).contiguous()

        edge_index = self.dilated_knn_graph(x, y, relative_pos)
        # print("x.shape", x.shape)
        # print("edge_index.shape", edge_index.shape)
        edge_index_dst, edge_index_src = edge_index[0], edge_index[1]
        # print("edge_index_src.shape", edge_index_src.shape)
        # B_multi_num_windows, shape_multi, k = edge_index_src.shape
        # self.output_folder = "/media/hitlab/ssd_2/spc/Dataset/nnUNet/nnUNet_results/Dataset990_angio_MRA_test/nnUNetTrainer_NexToU_Plus__nnUNetPlans__3d_fullres/fold_0"
        
        # edge_src_path = self.output_folder + "/pool_dgc_edge_src" + "_" + str(B_multi_num_windows) + "_" + str(shape_multi) + "_" + str(k)
        # edge_index_src_np = edge_index_src.detach().cpu().numpy().reshape(B_multi_num_windows, S, H, W, k).transpose((0, 4, 1, 2, 3))
        # maybe_mkdir_p(edge_src_path)
        # for w_idx in range(B_multi_num_windows):
        #     for k_idx in range(k):
        #         tmp_np = edge_index_src_np[w_idx, k_idx]
        #         nifti_data_img1 = nib.Nifti1Image(tmp_np, np.eye(4))
        #         nib.save(nifti_data_img1, edge_src_path + "/" + f'edge_src_w_{w_idx}_k_{k_idx}_.nii.gz')

        # edge_src_path = self.output_folder + "/pool_dgc_edge_dst" + "_" + str(B_multi_num_windows) + "_" + str(shape_multi) + "_" + str(k)
        # edge_index_dst_np = edge_index_dst.detach().cpu().numpy().reshape(B_multi_num_windows, S, H, W, k).transpose((0, 4, 1, 2, 3))
        # maybe_mkdir_p(edge_src_path)
        # for w_idx in range(B_multi_num_windows):
        #     for k_idx in range(k):
        #         tmp_np = edge_index_dst_np[w_idx, k_idx]
        #         nifti_data_img1 = nib.Nifti1Image(tmp_np, np.eye(4))
        #         nib.save(nifti_data_img1, edge_src_path + "/" + f'edge_dst_w_{w_idx}_k_{k_idx}_.nii.gz')

        # if y != None:
        #     print("y.shape", y.shape)
        # else:
        #     pass
        # if relative_pos != None:
        #     print("relative_pos.shape", relative_pos.shape)
        # else:
        #     pass  
        x = super(PoolDyGraphConv, self).forward(x, edge_index, y)
        
        indices_cat = torch.cat((indices, indices), 1)
        
        if self.conv_op == nn.Conv2d:
            H_pool, W_pool = H // self.pool_size[0], W // self.pool_size[1]
            x = x.reshape(B, -1, H_pool, W_pool).contiguous()
            indices_cat = indices_cat.reshape(B, -1, H_pool, W_pool).contiguous()
        elif self.conv_op == nn.Conv3d:
            S_pool, H_pool, W_pool = S // self.pool_size[0], H // self.pool_size[1], W // self.pool_size[2]
            x = x.reshape(B, -1, S_pool, H_pool, W_pool).contiguous()
            indices_cat = indices_cat.reshape(B, -1, S_pool, H_pool, W_pool).contiguous()
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)
        
        x = self.max_unpool_output(x, indices_cat)

        return x
        
class Grapher(nn.Module):
    """
    Grapher module with graph convolution and fc layers
    """
    def __init__(self, in_channels, kernel_size=9, dilation=1, conv='edge', act='relu', norm=None,
                 bias=True,  stochastic=False, epsilon=0.0, r=1, n=196, drop_path=0.0, relative_pos=False, 
                 conv_op=nn.Conv3d, norm_op=nn.BatchNorm3d, dropout_op=nn.Dropout3d):
        super(Grapher, self).__init__()
        self.channels = in_channels
        self.n = n
        self.r = r
        self.conv_op = conv_op
        base_channels = in_channels - 3
        self.fc1 = nn.Sequential(
            conv_op(in_channels, base_channels, 1, stride=1, padding=0),
            norm_op(base_channels),
        )
        self.graph_conv = Raw_DyGraphConv(base_channels, base_channels * 2, kernel_size, dilation, conv,
                                      act, norm, bias, stochastic, epsilon, r, conv_op, dropout_op)
        self.fc2 = nn.Sequential(
            conv_op(base_channels * 2, in_channels, 1, stride=1, padding=0),
            norm_op(in_channels),
        )
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.relative_pos = None
        if relative_pos:
            if self.conv_op == nn.Conv2d:
                relative_pos_tensor = torch.from_numpy(np.float32(get_2d_relative_pos_embed(base_channels,
                int(n**(1/2))))).unsqueeze(0).unsqueeze(1)
                relative_pos_tensor = F.interpolate(
                        relative_pos_tensor, size=(n, n//(r*r)), mode='bicubic', align_corners=False)
            elif self.conv_op == nn.Conv3d:
                # print("base_channels", base_channels)
                relative_pos_tensor = torch.from_numpy(np.float32(get_3d_relative_pos_embed(base_channels,
                int(n**(1/3))))).unsqueeze(0).unsqueeze(1) 
                relative_pos_tensor = F.interpolate(
                        relative_pos_tensor, size=(n, n//(r*r*r)), mode='bicubic', align_corners=False)
            else:
                raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)
            self.relative_pos = nn.Parameter(-relative_pos_tensor.squeeze(1), requires_grad=False)

    def _get_relative_pos(self, relative_pos, size_tuple):
        if self.conv_op == nn.Conv2d:
            H, W = size_tuple
            if relative_pos is None or H * W == self.n:
                return relative_pos
            else:
                N = H * W
                N_reduced = N // (self.r * self.r)
                return F.interpolate(relative_pos.unsqueeze(0), size=(N, N_reduced), mode="bicubic").squeeze(0)

        elif self.conv_op == nn.Conv3d:
            H, W, D = size_tuple
            if relative_pos is None or H * W * D == self.n:
                return relative_pos
            else:
                N = H * W * D
                N_reduced = N // (self.r * self.r * self.r)
                return F.interpolate(relative_pos.unsqueeze(0), size=(N, N_reduced), mode="bicubic").squeeze(0)
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)

        
    def forward(self, x):
        _tmp = x
        x = self.fc1(x)
        if self.conv_op == nn.Conv2d:
            B, C, H, W = x.shape
            size_tuple = (H, W)
            relative_pos = self._get_relative_pos(self.relative_pos, size_tuple)
        elif self.conv_op == nn.Conv3d:
            B, C, H, W, D = x.shape
            size_tuple = (H, W, D)
            relative_pos = self._get_relative_pos(self.relative_pos, size_tuple)
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)
        
        x = self.graph_conv(x, relative_pos)
        x = self.fc2(x)
        x = self.drop_path(x) + _tmp
        return x
    
def window_partition(x, window_size):
    """
    Args:
        x: (B, C, S, H, W) or (B, C, H, W)
        window_size (int): window size

    Returns:
        windows: (num_windows*B, window_size, window_size, window_size, C)
    """
    
    if len(x.shape) == 4:
        B, C, H, W = x.shape
        x = x.permute(0, 2, 3, 1)
        windows = rearrange(x, 'b (h p1) (w p2) c -> (b h w) p1 p2 c',
                            p1=window_size[0], p2=window_size[1], c=C)
        windows = windows.permute(0, 3, 1, 2)

    elif len(x.shape) == 5:
        B, C, S, H, W = x.shape
        x = x.permute(0, 2, 3, 4, 1)
        windows = rearrange(x, 'b (s p1) (h p2) (w p3) c -> (b s h w) p1 p2 p3 c',
                            p1=window_size[0], p2=window_size[1], p3=window_size[2], c=C)
        windows = windows.permute(0, 4, 1, 2, 3)
    else:
        raise NotImplementedError('len(x.shape) [%d] is equal to 4 or 5' % len(x.shape))
    
    return windows

def window_reverse(windows, window_size, size_tuple):
    """
    Args:
        windows: (num_windows*B, C, window_size, window_size, window_size)
        window_size (int): Window size
        S (int): Slice of image
        H (int): Height of image
        W (int): Width of image

    Returns:
        x: (B, C, S ,H, W)
    """
    if len(windows.shape) == 4:
        H, W = size_tuple
        B = torch.floor(torch.tensor(windows.shape[0] / (H * W / window_size[0] / window_size[1])))
        windows = windows.permute(0, 2, 3, 1)
        x = rearrange(windows, '(b h w) p1 p2 c -> b (h p1) (w p2) c',
                    p1=window_size[0], p2=window_size[1], b=B, h=H//window_size[0], w=W//window_size[1])
        x = x.permute(0, 3, 1, 2)

    elif len(windows.shape) == 5:
        S, H, W = size_tuple
        B = torch.floor(torch.tensor(windows.shape[0] / (S * H * W / window_size[0] / window_size[1] / window_size[2])))  
        windows = windows.permute(0, 2, 3, 4, 1)
        x = rearrange(windows, '(b s h w) p1 p2 p3 c -> b (s p1) (h p2) (w p3) c',
                    p1=window_size[0], p2=window_size[1], p3=window_size[2], b=int(B.clone().numpy()),
                    s=S//window_size[0], h=H//window_size[1], w=W//window_size[2])
        x = x.permute(0, 4, 1, 2, 3)
    else:
        raise NotImplementedError('len(x.shape) [%d] is equal to 4 or 5' % len(x.shape))

    return x

class SwinGrapher(nn.Module):
    """
    SwinGrapher module with graph convolution and fc layers
    """
    def __init__(self, in_channels, img_shape, kernel_size=9, dilation=1, conv='edge', act='relu', norm=None,
                 bias=True,  stochastic=False, epsilon=0.0, r=1, n=196, drop_path=0.0, relative_pos=False, 
                 conv_op=nn.Conv3d, norm_op=nn.BatchNorm3d, norm_op_kwargs=None, dropout_op=nn.Dropout3d, window_size=[3, 6, 6], shift_size=[0, 0, 0]):
        super(SwinGrapher, self).__init__()
        self.channels = in_channels
        # self.n = n
        self.r = r
        self.conv_op = conv_op
        self.img_shape = img_shape
        self.window_size = window_size
        self.shift_size = shift_size

        self.fc1 = nn.Sequential(
            conv_op(in_channels, in_channels, 1, stride=1, padding=0),
            norm_op(in_channels, **norm_op_kwargs),
        )
        norm = 'batch'
        self.graph_conv = DyGraphConv(in_channels, in_channels * 2, kernel_size, dilation, conv,
                                      act, norm, bias, stochastic, epsilon, r, conv_op, dropout_op)
        self.fc2 = nn.Sequential(
            conv_op(in_channels * 2, in_channels, 1, stride=1, padding=0),
            norm_op(in_channels, **norm_op_kwargs),
        )
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

        n = 1
        for h in self.window_size:
            n = n * h
        self.n = n
        self.relative_pos = None
        if relative_pos:
            
            if self.conv_op == nn.Conv2d:
                relative_pos_tensor = torch.from_numpy(np.float32(get_2d_relative_pos_embed(in_channels,
                int(n**(1/2))))).unsqueeze(0).unsqueeze(1) ####
                relative_pos_tensor = F.interpolate(
                        relative_pos_tensor, size=(n, n//(r*r)), mode='bicubic', align_corners=False)
            elif self.conv_op == nn.Conv3d:
                relative_pos_tensor = torch.from_numpy(np.float32(get_3d_relative_pos_embed(in_channels,
                int(n**(1/3))))).unsqueeze(0).unsqueeze(1) ####
                relative_pos_tensor = F.interpolate(
                        relative_pos_tensor, size=(n, n//(r*r*r)), mode='bicubic', align_corners=False)
            else:
                raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)
            self.relative_pos = nn.Parameter(-relative_pos_tensor.squeeze(1), requires_grad=False)

    def _get_relative_pos(self, relative_pos, window_size_tuple):
        if self.conv_op == nn.Conv2d:
            H, W = window_size_tuple
            if relative_pos is None or torch.all(torch.tensor(H * W).eq(self.n)):
                return relative_pos
            else:
                N = H * W
                N_reduced = N // (self.r * self.r)
                return F.interpolate(relative_pos.unsqueeze(0), size=(N, N_reduced), mode="bicubic").squeeze(0)

        elif self.conv_op == nn.Conv3d:
            S, H, W = window_size_tuple
            if relative_pos is None or torch.all(torch.tensor(S * H * W).eq(self.n)):
                return relative_pos
            else:
                N = S * H * W
                N_reduced = N // (self.r * self.r * self.r)
                return F.interpolate(relative_pos.unsqueeze(0), size=(N, N_reduced), mode="bicubic").squeeze(0)
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)

        
    def forward(self, x):
        _tmp = x
        if self.conv_op == nn.Conv2d:
            B, C, H, W = x.shape
            size_tuple = (H, W)
            h, w = self.img_shape
            assert torch.all(torch.tensor(H).eq(h)) and torch.all(torch.tensor(W).eq(w)), "input feature has wrong size"
        elif self.conv_op == nn.Conv3d:
            B, C, S, H, W = x.shape
            size_tuple = (S, H, W)
            s, h, w = self.img_shape
            assert torch.all(torch.tensor(S).eq(s)) and torch.all(torch.tensor(H).eq(h)) and torch.all(torch.tensor(W).eq(w)), "input feature has wrong size"
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)

        if max(self.shift_size) > 0 and self.conv_op == nn.Conv2d:
            shifted_x = torch.roll(x, shifts=(-self.shift_size[0], -self.shift_size[1]), dims=(2, 3))
        elif max(self.shift_size) > 0 and self.conv_op == nn.Conv3d:
            shifted_x = torch.roll(x, shifts=(-self.shift_size[0], -self.shift_size[1], -self.shift_size[2]), dims=(2, 3, 4))
        else:
            shifted_x = x

        # partition windows
        # nW*B, C, window_size, window_size, window_size
        x_windows = window_partition(shifted_x, self.window_size)
        # print("x_windows.shape: ", x_windows.shape)
        x = self.fc1(x_windows)

        if self.conv_op == nn.Conv2d:
            B_, C, H, W = x.shape
            window_size_tuple = (H, W)
            relative_pos = self._get_relative_pos(self.relative_pos, window_size_tuple)
        elif self.conv_op == nn.Conv3d:
            B_, C, S, H, W = x.shape
            window_size_tuple = (S, H, W)
            relative_pos = self._get_relative_pos(self.relative_pos, window_size_tuple)
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)
        
        x = self.graph_conv(x, relative_pos)

        gnn_windows = self.fc2(x)
        # print("gnn_windows.shape: ", gnn_windows.shape)
        shifted_x = window_reverse(gnn_windows, self.window_size, size_tuple)

        # reverse cyclic shift
        if max(self.shift_size) > 0 and self.conv_op == nn.Conv2d:
            x = torch.roll(shifted_x, shifts=(self.shift_size[0], self.shift_size[1]), dims=(2, 3))
        elif max(self.shift_size) > 0 and self.conv_op == nn.Conv3d:
            x = torch.roll(shifted_x, shifts=(self.shift_size[0], self.shift_size[1], self.shift_size[2]), dims=(2, 3, 4))
        else:
            x = shifted_x

        x = self.drop_path(x) + _tmp
        return x

class VesselGrapher(nn.Module):
    """
    VesselGrapher module with graph convolution and fc layers
    """
    def __init__(self, in_channels, img_shape, kernel_size=9, dilation=1, conv='edge', act='relu', norm=None,
                 bias=True,  stochastic=False, epsilon=0.0, r=1, n=196, drop_path=0.0, relative_pos=False, 
                 conv_op=nn.Conv3d, norm_op=nn.BatchNorm3d, norm_op_kwargs=None, dropout_op=nn.Dropout3d):
        super(VesselGrapher, self).__init__()
        self.channels = in_channels
        # self.n = n
        self.r = r
        self.conv_op = conv_op
        self.img_shape = img_shape

        self.fc1 = nn.Sequential(
            conv_op(in_channels, in_channels, 1, stride=1, padding=0),
            norm_op(in_channels, **norm_op_kwargs),
        )
        norm = 'batch'
        self.graph_conv = DyGraphConv(in_channels, in_channels * 2, kernel_size, dilation, conv,
                                      act, norm, bias, stochastic, epsilon, r, conv_op, dropout_op)
        self.fc2 = nn.Sequential(
            conv_op(in_channels * 2, in_channels, 1, stride=1, padding=0),
            norm_op(in_channels, **norm_op_kwargs),
        )
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

        # n = 1
        # for h in self.window_size:
        #     n = n * h
        # self.n = n
        self.relative_pos = None
        # if relative_pos:
            
        #     if self.conv_op == nn.Conv2d:
        #         relative_pos_tensor = torch.from_numpy(np.float32(get_2d_relative_pos_embed(in_channels,
        #         int(n**(1/2))))).unsqueeze(0).unsqueeze(1) ####
        #         relative_pos_tensor = F.interpolate(
        #                 relative_pos_tensor, size=(n, n//(r*r)), mode='bicubic', align_corners=False)
        #     elif self.conv_op == nn.Conv3d:
        #         relative_pos_tensor = torch.from_numpy(np.float32(get_3d_relative_pos_embed(in_channels,
        #         int(n**(1/3))))).unsqueeze(0).unsqueeze(1) ####
        #         relative_pos_tensor = F.interpolate(
        #                 relative_pos_tensor, size=(n, n//(r*r*r)), mode='bicubic', align_corners=False)
        #     else:
        #         raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)
        #     self.relative_pos = nn.Parameter(-relative_pos_tensor.squeeze(1), requires_grad=False)

    # def _get_relative_pos(self, relative_pos, window_size_tuple):
    #     if self.conv_op == nn.Conv2d:
    #         H, W = window_size_tuple
    #         if relative_pos is None or torch.all(torch.tensor(H * W).eq(self.n)):
    #             return relative_pos
    #         else:
    #             N = H * W
    #             N_reduced = N // (self.r * self.r)
    #             return F.interpolate(relative_pos.unsqueeze(0), size=(N, N_reduced), mode="bicubic").squeeze(0)

    #     elif self.conv_op == nn.Conv3d:
    #         S, H, W = window_size_tuple
    #         if relative_pos is None or torch.all(torch.tensor(S * H * W).eq(self.n)):
    #             return relative_pos
    #         else:
    #             N = S * H * W
    #             N_reduced = N // (self.r * self.r * self.r)
    #             return F.interpolate(relative_pos.unsqueeze(0), size=(N, N_reduced), mode="bicubic").squeeze(0)
    #     else:
    #         raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)
    
    def forward(self, x, windows_seg_target, windows_graph_edges_target, windows_graph_nodes, current_epoch, m2g2m=True, val_flag=False, test_flag=True):
        _tmp = x
        if self.conv_op == nn.Conv2d:
            B, C, H, W = x.shape
            size_tuple = (H, W)
            h, w = self.img_shape
            assert torch.all(torch.tensor(H).eq(h)) and torch.all(torch.tensor(W).eq(w)), "input feature has wrong size"
        elif self.conv_op == nn.Conv3d:
            B, C, S, H, W = x.shape
            size_tuple = (S, H, W)
            s, h, w = self.img_shape
            assert torch.all(torch.tensor(S).eq(s)) and torch.all(torch.tensor(H).eq(h)) and torch.all(torch.tensor(W).eq(w)), "input feature has wrong size"
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)

        x = self.fc1(x)

        # if self.conv_op == nn.Conv2d:
        #     B_, C, H, W = x.shape
        #     window_size_tuple = (H, W)
        #     relative_pos = self._get_relative_pos(self.relative_pos, window_size_tuple)
        # elif self.conv_op == nn.Conv3d:
        #     B_, C, S, H, W = x.shape
        #     window_size_tuple = (S, H, W)
        #     relative_pos = self._get_relative_pos(self.relative_pos, window_size_tuple)
        # else:
        #     raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)
        if m2g2m and test_flag:
            x, loss_graph_mean, skel_pred = self.graph_conv(x, relative_pos=None, windows_seg_target=windows_seg_target, windows_graph_edges_target=windows_graph_edges_target, windows_graph_nodes=windows_graph_nodes, img_shape=self.img_shape, current_epoch=current_epoch, m2g2m=m2g2m, val_flag=val_flag, test_flag=test_flag)
            gnn_windows = self.fc2(x)
            # print("gnn_windows.shape: ", gnn_windows.shape)
            x = gnn_windows #window_reverse(gnn_windows, self.window_size, size_tuple)

            x = self.drop_path(x) + _tmp
            return x, loss_graph_mean, skel_pred
        
        else:
            x, loss_graph_mean = self.graph_conv(x, relative_pos=None, windows_seg_target=windows_seg_target, windows_graph_edges_target=windows_graph_edges_target, windows_graph_nodes=windows_graph_nodes, img_shape=self.img_shape, current_epoch=current_epoch, m2g2m=m2g2m, val_flag=val_flag, test_flag=test_flag)

            gnn_windows = self.fc2(x)
            # print("gnn_windows.shape: ", gnn_windows.shape)
            x = gnn_windows #window_reverse(gnn_windows, self.window_size, size_tuple)

            x = self.drop_path(x) + _tmp
            return x, loss_graph_mean
    
class WinGrapher(nn.Module):
    """
    WinGrapher module with graph convolution and fc layers
    """
    def __init__(self, in_channels, img_shape, kernel_size=9, dilation=1, conv='edge', act='relu', norm=None,
                 bias=True,  stochastic=False, epsilon=0.0, r=1, n=196, drop_path=0.0, relative_pos=False, 
                 conv_op=nn.Conv3d, norm_op=nn.BatchNorm3d, norm_op_kwargs=None, dropout_op=nn.Dropout3d, window_size=[3, 6, 6]):
        super(WinGrapher, self).__init__()
        self.channels = in_channels
        # self.n = n
        self.r = r
        self.conv_op = conv_op
        self.img_shape = img_shape
        self.window_size = window_size

        self.fc1 = nn.Sequential(
            conv_op(in_channels, in_channels, 1, stride=1, padding=0),
            norm_op(in_channels, **norm_op_kwargs),
        )
        norm = 'batch'
        self.graph_conv = DyGraphConv(in_channels, in_channels * 2, kernel_size, dilation, conv,
                                      act, norm, bias, stochastic, epsilon, r, conv_op, dropout_op)
        self.fc2 = nn.Sequential(
            conv_op(in_channels * 2, in_channels, 1, stride=1, padding=0),
            norm_op(in_channels, **norm_op_kwargs),
        )
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

        n = 1
        for h in self.window_size:
            n = n * h
        self.n = n
        self.relative_pos = None
        if relative_pos:
            
            if self.conv_op == nn.Conv2d:
                relative_pos_tensor = torch.from_numpy(np.float32(get_2d_relative_pos_embed(in_channels,
                int(n**(1/2))))).unsqueeze(0).unsqueeze(1) ####
                relative_pos_tensor = F.interpolate(
                        relative_pos_tensor, size=(n, n//(r*r)), mode='bicubic', align_corners=False)
            elif self.conv_op == nn.Conv3d:
                relative_pos_tensor = torch.from_numpy(np.float32(get_3d_relative_pos_embed(in_channels,
                int(n**(1/3))))).unsqueeze(0).unsqueeze(1) ####
                relative_pos_tensor = F.interpolate(
                        relative_pos_tensor, size=(n, n//(r*r*r)), mode='bicubic', align_corners=False)
            else:
                raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)
            self.relative_pos = nn.Parameter(-relative_pos_tensor.squeeze(1), requires_grad=False)

    def _get_relative_pos(self, relative_pos, window_size_tuple):
        if self.conv_op == nn.Conv2d:
            H, W = window_size_tuple
            if relative_pos is None or torch.all(torch.tensor(H * W).eq(self.n)):
                return relative_pos
            else:
                N = H * W
                N_reduced = N // (self.r * self.r)
                return F.interpolate(relative_pos.unsqueeze(0), size=(N, N_reduced), mode="bicubic").squeeze(0)

        elif self.conv_op == nn.Conv3d:
            S, H, W = window_size_tuple
            if relative_pos is None or torch.all(torch.tensor(S * H * W).eq(self.n)):
                return relative_pos
            else:
                N = S * H * W
                N_reduced = N // (self.r * self.r * self.r)
                return F.interpolate(relative_pos.unsqueeze(0), size=(N, N_reduced), mode="bicubic").squeeze(0)
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)
    
    def forward(self, x, windows_seg_target, windows_graph_edges_target, windows_graph_nodes, current_epoch, m2g2m=True, val_flag=False):
        _tmp = x
        if self.conv_op == nn.Conv2d:
            B, C, H, W = x.shape
            size_tuple = (H, W)
            h, w = self.img_shape
            assert torch.all(torch.tensor(H).eq(h)) and torch.all(torch.tensor(W).eq(w)), "input feature has wrong size"
        elif self.conv_op == nn.Conv3d:
            B, C, S, H, W = x.shape
            size_tuple = (S, H, W)
            s, h, w = self.img_shape
            assert torch.all(torch.tensor(S).eq(s)) and torch.all(torch.tensor(H).eq(h)) and torch.all(torch.tensor(W).eq(w)), "input feature has wrong size"
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)

        # partition windows
        # nW*B, C, window_size, window_size, window_size
        x_windows = window_partition(x, self.window_size)
        # print("x_windows.shape: ", x_windows.shape)
        x = self.fc1(x_windows)

        if self.conv_op == nn.Conv2d:
            B_, C, H, W = x.shape
            window_size_tuple = (H, W)
            relative_pos = self._get_relative_pos(self.relative_pos, window_size_tuple)
        elif self.conv_op == nn.Conv3d:
            B_, C, S, H, W = x.shape
            window_size_tuple = (S, H, W)
            relative_pos = self._get_relative_pos(self.relative_pos, window_size_tuple)
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)
        
        # mask_bool_t_0 = windows_graph_nodes > 0
        # num_true = mask_bool_t_0.sum().item()
        # if num_true > 0 and m2g2m:
        #     m2g2m = True
        # else:
        #     m2g2m = False
        x, loss_graph_mean = self.graph_conv(x, relative_pos=relative_pos, windows_seg_target=windows_seg_target, windows_graph_edges_target=windows_graph_edges_target, windows_graph_nodes=windows_graph_nodes, img_shape=self.img_shape, current_epoch=current_epoch, m2g2m=m2g2m, val_flag=val_flag)

        gnn_windows = self.fc2(x)
        # print("gnn_windows.shape: ", gnn_windows.shape)
        x = window_reverse(gnn_windows, self.window_size, size_tuple)

        x = self.drop_path(x) + _tmp
        return x, loss_graph_mean
    
class PoolGrapher(nn.Module):
    """
    PoolGrapher module with graph convolution and fc layers
    """
    def __init__(self, in_channels, img_shape, kernel_size=9, dilation=1, conv='edge', act='relu', norm=None,
                 bias=True,  stochastic=False, epsilon=0.0, r=1, n=196, drop_path=0.0, relative_pos=False, 
                 conv_op=nn.Conv3d, norm_op=nn.BatchNorm3d, norm_op_kwargs=None, dropout_op=nn.Dropout3d, img_min_shape=None):
        super(PoolGrapher, self).__init__()
        self.channels = in_channels
        # self.n = n
        self.r = r
        self.conv_op = conv_op
        self.img_shape = img_shape
        

        self.fc1 = nn.Sequential(
            conv_op(in_channels, in_channels, 1, stride=1, padding=0),
            norm_op(in_channels, **norm_op_kwargs),
        )
        self.graph_conv = PoolDyGraphConv(in_channels, in_channels * 2, kernel_size, dilation, conv,
                                      act, norm, bias, stochastic, epsilon, r, conv_op, dropout_op, img_shape=img_shape, img_min_shape=img_min_shape)
        self.fc2 = nn.Sequential(
            conv_op(in_channels * 2, in_channels, 1, stride=1, padding=0),
            norm_op(in_channels, **norm_op_kwargs),
        )
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

        n = 1
        for h in img_shape:
            n = n * h
        
        n_small = 1
        for h_small in img_min_shape:
            n_small = n_small * h_small * 4

        if n > n_small:
            pool_size = [2 if h % 2 == 0 else 1 for h in img_shape]
        else:
            pool_size = [1 for h in img_shape]
        
        self.pool_size = pool_size
        
        p_num = 1
        for p in pool_size:
            p_num = p_num * p

        n = n // p_num
        self.n = n
        self.relative_pos = None
        if relative_pos:
            if self.conv_op == nn.Conv2d:
                relative_pos_tensor = torch.from_numpy(np.float32(get_2d_relative_pos_embed(in_channels,
                int(n**(1/2))))).unsqueeze(0).unsqueeze(1) 
                relative_pos_tensor = F.interpolate(
                        relative_pos_tensor, size=(n, n//(r*r)), mode='bicubic', align_corners=False)
            elif self.conv_op == nn.Conv3d:
                relative_pos_tensor = torch.from_numpy(np.float32(get_3d_relative_pos_embed(in_channels,
                int(n**(1/3))))).unsqueeze(0).unsqueeze(1) 
                relative_pos_tensor = F.interpolate(
                        relative_pos_tensor, size=(n, n//(r*r*r)), mode='bicubic', align_corners=False)
            else:
                raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)
            self.relative_pos = nn.Parameter(-relative_pos_tensor.squeeze(1), requires_grad=False)

    def _get_relative_pos(self, relative_pos, size_tuple):
        if self.conv_op == nn.Conv2d:
            H, W = size_tuple
            if relative_pos is None or torch.all(torch.tensor(H * W).eq(self.n)):
                return relative_pos
            else:
                N = H * W
                N_reduced = N // (self.r * self.r)
                return F.interpolate(relative_pos.unsqueeze(0), size=(N, N_reduced), mode="bicubic").squeeze(0)

        elif self.conv_op == nn.Conv3d:
            S, H, W = size_tuple
            if relative_pos is None or torch.all(torch.tensor(S * H * W).eq(self.n)):
                return relative_pos
            else:
                N = S * H * W
                N_reduced = N // (self.r * self.r * self.r)
                return F.interpolate(relative_pos.unsqueeze(0), size=(N, N_reduced), mode="bicubic").squeeze(0)
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)

        
    def forward(self, x):
        _tmp = x
        if self.conv_op == nn.Conv2d:
            B, C, H, W = x.shape
            size_tuple = (H, W)
            h, w = self.img_shape
        elif self.conv_op == nn.Conv3d:
            B, C, S, H, W = x.shape
            size_tuple = (S, H, W)
            s, h, w = self.img_shape
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)

        x = self.fc1(x)
        if self.conv_op == nn.Conv2d:
            B_, C, H, W = x.shape
            size_tuple = (H // self.pool_size[0], W // self.pool_size[1])
            relative_pos = self._get_relative_pos(self.relative_pos, size_tuple)
        elif self.conv_op == nn.Conv3d:
            B_, C, S, H, W = x.shape
            size_tuple = (S // self.pool_size[0], H // self.pool_size[1], W // self.pool_size[2])
            relative_pos = self._get_relative_pos(self.relative_pos, size_tuple)
        else:
            raise NotImplementedError('conv operation [%s] is not found' % self.conv_op)
        
        x = self.graph_conv(x, relative_pos)
        x = self.fc2(x)

        x = self.drop_path(x) + _tmp
        return x

class Efficient_ViG_blocks(nn.Module):
    def __init__(self, channels, img_shape, index, conv_layer_d_num, opt=None, conv_op=nn.Conv3d, norm_op=nn.BatchNorm3d, norm_op_kwargs=None,
                    dropout_op=nn.Dropout3d, **kwargs):
        super(Efficient_ViG_blocks, self).__init__()

        vig_blocks = []
        ffn_blocks = []
        k = opt.k
        conv = opt.conv
        act = opt.act
        norm = opt.norm
        bias = opt.bias
        epsilon = opt.epsilon
        stochastic = opt.use_stochastic
        drop_path = opt.drop_path
        reduce_ratios = opt.reduce_ratios 
        blocks_num_list = opt.blocks
        n_size_list = opt.n_size_list
        img_min_shape = opt.img_min_shape

        self.n_blocks = sum(blocks_num_list)        
        # stochastic depth decay rule
        dpr = [x.item() for x in torch.linspace(0, drop_path, self.n_blocks)]
        sum_blocks = sum(blocks_num_list[conv_layer_d_num-2:index])
        idx_list = [(k+sum_blocks) for k in range(0, blocks_num_list[index])]
        
        
        if conv_op == nn.Conv2d:
            H_min, W_min = img_min_shape
            max_dilation = (H_min * W_min) // max(k)
            window_size = img_min_shape
            window_size_n = window_size[0] * window_size[1]   
        elif conv_op == nn.Conv3d:
            H_min, W_min, D_min = img_min_shape
            max_dilation = (H_min * W_min * D_min) // max(k)  
            window_size = img_min_shape
            window_size_n = window_size[0] * window_size[1] * window_size[2]      
        else:
            raise NotImplementedError('conv operation [%s] is not found' % conv_op)

        i = conv_layer_d_num-2 + index
        for j in range(blocks_num_list[index]):
            idx = idx_list[j]
            if conv_op == nn.Conv2d:
                shift_size = [window_size[0] // 2, window_size[1] // 2]
            elif conv_op == nn.Conv3d:
                shift_size = [window_size[0] // 2, window_size[1] // 2, window_size[2] // 2]
            else:
                raise NotImplementedError('conv operation [%s] is not found' % conv_op)

            # blocks.append(nn.Sequential(
            #         # PoolGrapher(channels, img_shape, k[i], min(idx // 4 + 1, max_dilation), conv, act, norm,
            #         # bias, stochastic, epsilon, reduce_ratios[i], n=n_size_list[i+2], drop_path=dpr[idx],
            #         # relative_pos=True, conv_op=conv_op, norm_op=norm_op, norm_op_kwargs=norm_op_kwargs, dropout_op=dropout_op, img_min_shape=img_min_shape), 
            #         # FFN(channels, channels * 4, act=act, drop_path=dpr[idx], conv_op=conv_op, norm_op=norm_op, norm_op_kwargs=norm_op_kwargs),
            #         # SwinGrapher(channels, img_shape, k[i], min(idx // 4 + 1, max_dilation), conv, act, norm,
            #         # bias, stochastic, epsilon, 1, n=window_size_n, drop_path=dpr[idx],
            #         # relative_pos=True, conv_op=conv_op, norm_op=norm_op, norm_op_kwargs=norm_op_kwargs, dropout_op=dropout_op, 
            #         # window_size=window_size, shift_size=shift_size), 
            #         # FFN(channels, channels * 4, act=act, drop_path=dpr[idx], conv_op=conv_op, norm_op=norm_op, norm_op_kwargs=norm_op_kwargs),
            #         Grapher(channels, k[i], min(idx // 4 + 1, max_dilation), conv, act, norm,
            #         bias, stochastic, epsilon, reduce_ratios[i], n=n_size_list[i+2], drop_path=dpr[idx],
            #         relative_pos=True, conv_op=conv_op, norm_op=norm_op, dropout_op=dropout_op),
            #         FFN(channels, channels * 4, act=act, drop_path=dpr[idx], conv_op=conv_op, norm_op=norm_op, norm_op_kwargs=norm_op_kwargs)))

            # window_size = [4, 6, 6] #[5, 16, 16] #[5, 8, 8] #[6, 9, 9] #[4, 12, 12] #[4, 6, 6] #[6, 9, 9]
            vig_blocks.append(
                        # Grapher(channels, k[i], min(idx // 4 + 1, max_dilation), conv, act, norm,
                        # bias, stochastic, epsilon, reduce_ratios[i], n=n_size_list[i+2], drop_path=dpr[idx],
                        # relative_pos=True, conv_op=conv_op, norm_op=norm_op, dropout_op=dropout_op))
                        # WinGrapher(channels, img_shape, k[i], min(idx // 4 + 1, max_dilation), conv, act, norm,
                        # bias, stochastic, epsilon, 1, window_size_n, drop_path=dpr[idx], relative_pos=True, conv_op=conv_op, norm_op=norm_op, 
                        # norm_op_kwargs=norm_op_kwargs, dropout_op=dropout_op, window_size=window_size))
                        VesselGrapher(channels, img_shape, k[i], min(idx // 4 + 1, max_dilation), conv, act, norm,
                        bias, stochastic, epsilon, 1, window_size_n, drop_path=dpr[idx], relative_pos=True, conv_op=conv_op, norm_op=norm_op, 
                        norm_op_kwargs=norm_op_kwargs, dropout_op=dropout_op))


            ffn_blocks.append(FFN(channels, channels * 4, act=act, drop_path=dpr[idx], conv_op=conv_op, norm_op=norm_op, norm_op_kwargs=norm_op_kwargs))
            
        # blocks = nn.Sequential(*blocks)
        # self.blocks = blocks

        self.vig_blocks = nn.ModuleList(vig_blocks)
        self.ffn_blocks = nn.ModuleList(ffn_blocks)

    def forward(self, x, windows_seg_target, windows_graph_edges_target, windows_graph_nodes, current_epoch, m2g2m=True, val_flag=False, test_flag=True): 
        # x = self.blocks(x)
        if m2g2m and test_flag:
            for i in range(len(self.vig_blocks)):
                x, loss_graph_mean, skel_pred = self.vig_blocks[i](x, windows_seg_target, windows_graph_edges_target, windows_graph_nodes, current_epoch, m2g2m=m2g2m, val_flag=val_flag, test_flag=test_flag)
                x = self.ffn_blocks[i](x)
            return x, loss_graph_mean, skel_pred
        else:
            for i in range(len(self.vig_blocks)):
                x, loss_graph_mean = self.vig_blocks[i](x, windows_seg_target, windows_graph_edges_target, windows_graph_nodes, current_epoch, m2g2m=m2g2m, val_flag=val_flag, test_flag=test_flag)
                x = self.ffn_blocks[i](x)
            return x, loss_graph_mean

class MLP(nn.Module):
    """ Very simple multi-layer perceptron (also called FFN)"""

    def __init__(self, input_dim, hidden_dim, output_dim, num_layers):
        super().__init__()
        self.num_layers = num_layers
        h = [hidden_dim] * (num_layers - 1)
        self.layers = nn.ModuleList(
            nn.Linear(n, k) for n, k in zip([input_dim] + h, h + [output_dim]))

    def forward(self, x):
        for i, layer in enumerate(self.layers):
            x = F.relu(layer(x)) if i < self.num_layers - 1 else layer(x)
        return x
    
class GraphPredictor(nn.Module):

    def __init__(self, decoder_dim):
        super(GraphPredictor, self).__init__()
        # window_size = [4, 6, 6] #5, 8, 8] #[5, 16, 16] #[w_x, w_y, w_z]
        # self.window_size = window_size
        # n = window_size[0] * window_size[1] * window_size[2]
        # k = 8
        # # max_dilation = n // k  
        # conv_op=nn.Conv3d
        # norm_op=nn.BatchNorm3d
        # dropout_op=nn.Dropout3d
        # norm_op_kwargs = {'eps': 1e-5, 'affine': True}

        self.fc1 = nn.Sequential(
            nn.Conv3d(decoder_dim, 3, 1, stride=1, padding=0, bias=True),
        )

    def forward(self, feature_map):

        graph_mlp_results = self.fc1(feature_map)

        return graph_mlp_results

class GraphEdgesPredictor(nn.Module):

    def __init__(self, decoder_dim):
        super(GraphEdgesPredictor, self).__init__()

        self.edges_mlp = MLP((decoder_dim + 3) * 2, decoder_dim, 2, 3)

    def forward(self, feature_map, src_edge, dst_edge):

        edge_emb = torch.cat((feature_map[src_edge, :], feature_map[dst_edge, :]), dim=1)
        graph_mlp_results = self.edges_mlp(edge_emb)


        return graph_mlp_results
