import os
import numpy as np
import SimpleITK as sitk
from tqdm import tqdm

def make_folder(folder):
    if not os.path.exists(folder):
        os.makedirs(folder)
    else:
        pass

def orientation_same(image_path, input_folder_name, output_folder_name):
    input_path = image_path + "/" + input_folder_name
    output_path = image_path + "/" + output_folder_name
    make_folder(output_path)
    case_index_list = os.listdir(input_path)
    print("Preprocess orientation same: ")
    for case_index in tqdm(case_index_list):       
        img_case_path = input_path + "/" + case_index + "/3D_TOF_MRA.nii.gz"
        case_image = sitk.ReadImage(img_case_path)
        case_image.SetDirection((1.0, 0.0, 0.0, 0.0, -1.0, 0.0, 0.0, 0.0, 1.0))
        sitk.WriteImage(case_image, output_path + "/sub" + case_index + "_0000.nii.gz")

def main():
    image_path = "/"
    input_folder_name = "input"
    output_folder_name = "input_nnUNet"
    orientation_same(image_path, input_folder_name, output_folder_name)

if __name__ == "__main__":
    main()

