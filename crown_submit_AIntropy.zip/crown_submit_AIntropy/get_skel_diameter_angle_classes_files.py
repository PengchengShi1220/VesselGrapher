import json
import os
import re
import numpy as np
import nibabel as nib
import networkx as nx
from skimage.morphology import skeletonize_3d, remove_small_objects
from scipy import ndimage
from tqdm import tqdm
from sklearn.neighbors import NearestNeighbors

def calculate_distance(coord1, coord2):
    return np.sqrt(np.sum((coord1 - coord2) ** 2))

def calculate_distance_vox(coord1, coord2, f):
    dist = np.sqrt(np.sum((coord1 - coord2) ** 2))
    dist = dist * f
    return dist

def calculate_angle(A, B, C):

    BA = A - B
    BC = C - B

    mag_BA = np.linalg.norm(BA)
    mag_BC = np.linalg.norm(BC)

    dot_product = np.dot(BA, BC)

    angle = np.arccos(dot_product / (mag_BA * mag_BC))

    angle = np.degrees(angle)

    return angle

def find_smallest_angle(points):
    smallest_angle = None
    smallest_angle_vertex = None
    for i in range(2, len(points)-2):
        angle = calculate_angle(points[i-2], points[i], points[i+2])
        # print("angle: ", angle)
        if smallest_angle is None or angle < smallest_angle and angle > 45:
            smallest_angle = angle
            smallest_angle_vertex = points[i]
    return smallest_angle_vertex, smallest_angle

def create_graph_from_centerline(centerline, num_neighbors):
    if len(centerline) < num_neighbors:
        # print("Insufficient samples. Need at least as many samples as neighbors.")
        return None
    
    nbrs = NearestNeighbors(n_neighbors=num_neighbors, algorithm='ball_tree').fit(centerline)
    distances, indices = nbrs.kneighbors(centerline)

    G = nx.Graph()

    for i in range(len(centerline)):
        G.add_node(i, pos=centerline[i])

    edges = [(i, indices[i, j], distances[i, j]) for i in range(len(centerline)) for j in range(1, num_neighbors)]

    G.add_weighted_edges_from(edges)

    T = nx.minimum_spanning_tree(G, algorithm="kruskal", weight="weight")

    return T

vessel_label_dict = {
    "A2(L)": 4,
    "A1(L)": 3,
    "M1(L)": 11,
    "ICA(L)": 8,
    "Pcom(L)": 15,
    "P1(L)": 18,
    "BA": 23,
    "VA(L)": 21,
    "VA(R)": 20,
    "P1(R)": 16,
    "Pcom(R)": 14,
    "ICA(R)": 7,
    "M1(R)": 9,
    "A1(R)": 1,
    "A2(R)": 2
    }

bifurcation_label_dict = {
    "A2_A1(L)": [4, 3, 6],
    "ICA top(L)": [3, 11, 8],
    "Pcom_ICA(L)": [8, 15],
    "M2_M2(L)": [11, 12],
    "BA top": [23], #[18, 23, 16],
    "A2_A1(R)": [1, 2, 6],
    "ICA top(R)": [1, 9, 7],
    "Pcom_ICA(R)": [7, 14],
    "M2_M2(R)": [9, 10],
    "VBJ": [23, 21, 20],
    "Pcom_P1(L)_for_ICA top(L)": [15], #[15, 18],
    "Pcom_P1(R)_for_ICA top(R)": [14], #[14, 16],
    "Pcom_P1(L)_for_BA top": [15, 18],
    "Pcom_P1(R)_for_BA top": [14, 16],
    "A2_top(L)": [4],
    "A2_top(R)": [2],
    "VA_bottom(L)": [21],
    "VA_bottom(R)": [20]
}


data_path = '/output_3d_multi_class_center_skel/'

file_list = os.listdir(data_path)

case_list = [re.findall(r'sub\d+', i)[0] for i in file_list if re.findall(r'sub\d+', i)]

case_list = list(set(case_list))
case_index_list = [i[3:] for i in case_list]

for case_index in tqdm(case_index_list):    
    # print("case_index: ", case_index)
    multi_class_img = nib.load(data_path + "sub" + case_index + ".nii.gz")
    multi_class_data_np = multi_class_img.get_fdata()

    img_hd = multi_class_img.header
    voxel_size = img_hd["pixdim"][1:4].tolist()
    # print("voxel_size: ", img_hd["pixdim"][1:4].tolist())
    skel_data_np = nib.load(data_path + "sub" + case_index + "_skel.nii.gz").get_fdata()
    # print("multi_class_data_np.shape: ", multi_class_data_np.shape)
    # print("skel_data_np.shape: ", skel_data_np.shape)

    skel_data_np_centerline = np.zeros_like(multi_class_data_np)
    skel_data_np_centerline[skel_data_np == 2] = 1

    vessel_data_np = np.zeros_like(multi_class_data_np)
    vessel_data_np[multi_class_data_np > 0] = 1

    vessel_data_np = remove_small_objects(vessel_data_np.astype(bool), min_size=200, connectivity=1).astype(np.int64)
    multi_class_data_np[vessel_data_np == 0] =0

    skel_3d = skeletonize_3d(vessel_data_np)
    skel_data_np_centerline[skel_3d == 1] = 1

    dist_map_3d_np = ndimage.distance_transform_edt(np.logical_not(1 - vessel_data_np))
    vessel_dist_map_3d_np = np.where(vessel_data_np == 0, -0.5, dist_map_3d_np)
    vessel_dist_map_3d_np[vessel_dist_map_3d_np == 1] = 0
    vessel_dist_map_3d_np[vessel_dist_map_3d_np > 0] = 1
    dist_map_3d_np = ndimage.distance_transform_edt(np.logical_not(1 - vessel_dist_map_3d_np))
    vessel_dist_map_3d_np = np.where(vessel_data_np == 0, -0.5, dist_map_3d_np)

    pos_seg_ba = np.where(multi_class_data_np == 23)
    pos_seg_ba = np.column_stack(pos_seg_ba)
    ba_upper_coord = pos_seg_ba[pos_seg_ba[:,2].argsort()][-1]
    # print("ba_upper_coord: ", ba_upper_coord)

    f = (voxel_size[0] ** 2 + voxel_size[1] ** 2 + voxel_size[2] ** 2) ** 0.5
    alpha = 0.8
    dist_dict = {}
    for v in vessel_label_dict:
        try:
            pos_a = np.where((multi_class_data_np == vessel_label_dict[v]) & (skel_data_np_centerline == 1))
            skel_coord_points = np.column_stack(pos_a)
            # print(v + " :", skel_coord_points)
            if len(skel_coord_points) == 0:
                dist_dict[v] = np.nan
                # print(v + " dist_dict[v]: ", dist_dict[v])
            else:
                if v in ["A2(L)", "A2(R)"]:
                    sorted_skele_coord_points = skel_coord_points[skel_coord_points[:,2].argsort()]
                    # print("sorted_skele_coord_points: ", sorted_skele_coord_points)
                    a2_lower_coord = sorted_skele_coord_points[0]
                    # print("a2_lower_coord: ", a2_lower_coord)

                    distances = np.array([calculate_distance_vox(a2_lower_coord, coord, f) for coord in skel_coord_points])
                    # print("distances: ", distances)
                    dist_diff_abs = np.abs(distances - 5)
                    min_distance = np.min(dist_diff_abs)
                    nearest_coords = skel_coord_points[dist_diff_abs == min_distance]
                    # print("The nearest coordinates to seg_avg_coord are: ", nearest_coords)

                    nearest_coords_radius = vessel_dist_map_3d_np[nearest_coords[:, 0], nearest_coords[:, 1], nearest_coords[:, 2]]
                    # print("nearest_coords_radius: ", nearest_coords_radius)
                    nearest_coords_radius = list(nearest_coords_radius)
                    nearest_coords_radius = [round(i*f*2*alpha, 3) for i in nearest_coords_radius]
                    if nearest_coords_radius[0] == 0:
                        dist_dict[v] = np.nan
                    else:
                        dist_dict[v] = nearest_coords_radius[0]

                    # print(v + " dist_dict[v]: ", dist_dict[v])
                
                elif v in ["P1(L)", "P1(R)"]:
                    # sorted_skele_coord_points = skel_coord_points[skel_coord_points[:,2].argsort()]
                    # print("sorted_skele_coord_points: ", sorted_skele_coord_points)
                    # a2_lower_coord = sorted_skele_coord_points[0]
                    # print("a2_lower_coord: ", a2_lower_coord)


                    distances = np.array([calculate_distance_vox(ba_upper_coord, coord, f) for coord in skel_coord_points])
                    # print("distances: ", distances)
                    # Get minimum distance and corresponding coordinate(s)
                    dist_diff_abs = np.abs(distances - 5)
                    min_distance = np.min(dist_diff_abs)
                    # if min_distance < 2:
                    nearest_coords = skel_coord_points[dist_diff_abs == min_distance]
                    # print("The nearest coordinates to seg_avg_coord are: ", nearest_coords)

                    nearest_coords_radius = vessel_dist_map_3d_np[nearest_coords[:, 0], nearest_coords[:, 1], nearest_coords[:, 2]]
                    # print("nearest_coords_radius: ", nearest_coords_radius)
                    nearest_coords_radius = list(nearest_coords_radius)
                    nearest_coords_radius = [round(i*f*2*alpha, 3) for i in nearest_coords_radius]
                    if nearest_coords_radius[0] == 0:
                        dist_dict[v] = np.nan
                    else:
                        dist_dict[v] = nearest_coords_radius[0]

                    # print(v + " dist_dict[v]: ", dist_dict[v])
                    # else:
                    #     dist_dict[v] = np.nan
                    #     print(v + " dist_dict[v]: ", dist_dict[v])
                
                elif v in ["ICA(L)", "ICA(R)"]:
                    pos_seg_a2 = np.where(multi_class_data_np == vessel_label_dict[v])
                    pos_seg_a2 = np.column_stack(pos_seg_a2)
                    ica_upper_coord = pos_seg_a2[pos_seg_a2[:,2].argsort()][-1]
                    ica_upper_coord[2] = ica_upper_coord[2] - 2
                    # print("ica_upper_coord: ", ica_upper_coord)
                    ica_upper_coord_z = ica_upper_coord[2]

                    # sorted_skele_coord_points = skel_coord_points[skel_coord_points[:,2].argsort()]
                    # print("sorted_skele_coord_points: ", sorted_skele_coord_points)
                    # ica_upper_coord = sorted_skele_coord_points[-1]
                    # print("ica_upper_coord: ", ica_upper_coord)

                    distances = np.array([calculate_distance_vox(ica_upper_coord, coord, f) for coord in skel_coord_points])
                    # print("distances: ", distances)
                    # Get minimum distance and corresponding coordinate(s)
                    dist_diff_abs = np.abs(distances - 5)
                    min_distance = np.min(dist_diff_abs)
                    # if min_distance < 2:
                    nearest_coords = skel_coord_points[dist_diff_abs == min_distance]
                    # print("The nearest coordinates to seg_avg_coord are: ", nearest_coords)

                    nearest_coords_radius = vessel_dist_map_3d_np[nearest_coords[:, 0], nearest_coords[:, 1], nearest_coords[:, 2]]
                    # print("nearest_coords_radius: ", nearest_coords_radius)
                    nearest_coords_radius = list(nearest_coords_radius)
                    nearest_coords_radius = [round(i*f*2*alpha, 3) for i in nearest_coords_radius]
                    if nearest_coords_radius[0] == 0:
                        dist_dict[v] = np.nan
                    else:
                        dist_dict[v] = nearest_coords_radius[0]
                    # print(v + " dist_dict[v]: ", dist_dict[v])
                
                elif v in ["BA", "VA(L)", "VA(R)"]:
                    sorted_skele_coord_points = skel_coord_points[skel_coord_points[:,2].argsort()]
                    # print("sorted_skele_coord_points: ", sorted_skele_coord_points)
                    upper_coord = sorted_skele_coord_points[-1]
                    # print("upper_coord: ", upper_coord)
                    if v == "BA":
                        upper_coord = upper_coord - 2
                    else:
                        pass

                    distances = np.array([calculate_distance_vox(upper_coord, coord, f) for coord in skel_coord_points])
                    # print("distances: ", distances)
                    # Get minimum distance and corresponding coordinate(s)
                    dist_diff_abs = np.abs(distances - 5)
                    min_distance = np.min(dist_diff_abs)
                    # if min_distance < 2:
                    nearest_coords = skel_coord_points[dist_diff_abs == min_distance]
                    # print("The nearest coordinates to seg_avg_coord are: ", nearest_coords)

                    nearest_coords_radius = vessel_dist_map_3d_np[nearest_coords[:, 0], nearest_coords[:, 1], nearest_coords[:, 2]]
                    # print("nearest_coords_radius: ", nearest_coords_radius)
                    nearest_coords_radius = list(nearest_coords_radius)
                    nearest_coords_radius = [round(i*f*2*alpha, 3) for i in nearest_coords_radius]
                    if nearest_coords_radius[0] == 0:
                        dist_dict[v] = np.nan
                    else:
                        dist_dict[v] = nearest_coords_radius[0]
                    # print(v + " dist_dict[v]: ", dist_dict[v])

                elif v in ["A1(L)", "A1(R)", "M1(L)", "M1(R)", "Pcom(L)", "Pcom(R)"]:
                    if v in ["M1(L)", "M1(R)"]:
                        coords_radius = vessel_dist_map_3d_np[skel_coord_points[:, 0], skel_coord_points[:, 1], skel_coord_points[:, 2]]
                        skel_coord_points = skel_coord_points[coords_radius*f*2*alpha >= 1.5]
                    else:
                        pass
                    if v in ["Pcom(L)", "Pcom(R)"]:
                        coords_radius = vessel_dist_map_3d_np[skel_coord_points[:, 0], skel_coord_points[:, 1], skel_coord_points[:, 2]]
                        skel_coord_points = skel_coord_points[coords_radius*f*2*alpha > 0]
                    else:
                        pass

                    total_length = np.sum([calculate_distance_vox(skel_coord_points[i], skel_coord_points[i+1], f) for i in range(len(skel_coord_points)-1)])

                    half_length = total_length / 2

                    current_length = 0
                    for i in range(len(skel_coord_points) - 1):
                        current_length += calculate_distance_vox(skel_coord_points[i], skel_coord_points[i+1], f)
                        if current_length >= half_length:
                            mid_point = skel_coord_points[i]
                            break

                    # print("Mid Point: ", mid_point)
                    # print(v + " :", seg_avg_coord)

                    distances = np.array([calculate_distance_vox(mid_point, coord, f) for coord in skel_coord_points])

                    # Get minimum distance and corresponding coordinate(s)
                    min_distance = np.min(distances)
                    nearest_coords = skel_coord_points[distances == min_distance]
                    # print("The nearest coordinates to seg_avg_coord are: ", nearest_coords)

                    nearest_coords_radius = vessel_dist_map_3d_np[nearest_coords[:, 0], nearest_coords[:, 1], nearest_coords[:, 2]]
                    # print("nearest_coords_radius: ", nearest_coords_radius)
                    nearest_coords_radius = list(nearest_coords_radius)
                    nearest_coords_radius = [round(i*f*2*alpha, 3) for i in nearest_coords_radius]
                    if nearest_coords_radius[0] == 0:
                        dist_dict[v] = np.nan
                    else:
                        dist_dict[v] = nearest_coords_radius[0]
                    # print(v + " dist_dict[v]: ", dist_dict[v])
                else:
                    pass
        except:
            dist_dict[v] = np.nan

    # print("dist_dict: ", dist_dict)
    for v in dist_dict:
        if v == "VA(L)" and np.isnan(dist_dict[v]):
            dist_dict[v] = 2.45
        elif v == "VA(R)" and np.isnan(dist_dict[v]):
            dist_dict[v] = 2.45
        elif v == "BA" and dist_dict[v] <= 1.8:
            dist_dict[v] = 2.4
        elif v == "P1(L)" and dist_dict[v] <= 1:
            dist_dict[v] = np.nan
        elif v == "P1(R)" and dist_dict[v] <= 1:
            dist_dict[v] = np.nan
        elif v == "Pcom(L)" and dist_dict[v] <= 1:
            dist_dict[v] = np.nan
        elif v == "Pcom(R)" and dist_dict[v] <= 1:
            dist_dict[v] = np.nan
        

    bifurcation_label_pos_dict = {}

    for b in bifurcation_label_dict:
        try:
            if b not in ["Pcom_P1(L)_for_ICA top(L)", "Pcom_P1(R)_for_ICA top(R)"]:
                pos_skel = np.where(np.isin(multi_class_data_np, bifurcation_label_dict[b]) & (skel_data_np_centerline == 1))
                skel_coord_points = np.column_stack(pos_skel)
                # print(b + " :", skel_coord_points)
                if b == "A2_A1(L)":
                    pos_seg = np.where(multi_class_data_np == 4)
                    pos_seg = np.column_stack(pos_seg)
                    if len(pos_seg) == 0:
                        distances = []
                    else:
                        a2_lower_coord = pos_seg[pos_seg[:,2].argsort()][0]
                        # print("a2_lower_coord: ", a2_lower_coord)

                        distances = np.array([calculate_distance_vox(a2_lower_coord, coord, f) for coord in skel_coord_points])

                elif b == "A2_A1(R)":
                    pos_seg = np.where(multi_class_data_np == 2)
                    pos_seg = np.column_stack(pos_seg)
                    if len(pos_seg) == 0:
                        distances = []
                    else:
                        a2_lower_coord = pos_seg[pos_seg[:,2].argsort()][0]
                        # print("a2_lower_coord: ", a2_lower_coord)

                        distances = np.array([calculate_distance_vox(a2_lower_coord, coord, f) for coord in skel_coord_points])

                elif b == "ICA top(L)":
                    pos_seg = np.where(multi_class_data_np == 8)
                    pos_seg = np.column_stack(pos_seg)
                    if len(pos_seg) == 0:
                        distances = []
                    else:
                        ica_upper_coord = pos_seg[pos_seg[:,2].argsort()][-1]
                        ica_upper_coord[2] = ica_upper_coord[2] - 2
                        # print("ica_upper_coord: ", ica_upper_coord)

                        distances = np.array([calculate_distance_vox(ica_upper_coord, coord, f) for coord in skel_coord_points])

                elif b == "ICA top(R)":
                    pos_seg = np.where(multi_class_data_np == 7)
                    pos_seg = np.column_stack(pos_seg)
                    if len(pos_seg) == 0:
                        distances = []
                    else:
                        ica_upper_coord = pos_seg[pos_seg[:,2].argsort()][-1]
                        ica_upper_coord[2] = ica_upper_coord[2] - 2
                        # print("ica_upper_coord: ", ica_upper_coord)

                        distances = np.array([calculate_distance_vox(ica_upper_coord, coord, f) for coord in skel_coord_points])

                elif b == "Pcom_ICA(L)":
                    pos_seg = np.where(multi_class_data_np == 15)
                    pos_seg = np.column_stack(pos_seg)
                    # print("pos_seg: ", pos_seg)
                    if len(pos_seg) == 0:
                        distances = []
                    else:
                        pcom_x_coord = pos_seg[pos_seg[:,0].argsort()][-1]
                        # print("pcom_x_coord: ", pcom_x_coord)

                        distances = np.array([calculate_distance_vox(pcom_x_coord, coord, f) for coord in skel_coord_points])

                elif b == "Pcom_ICA(R)":
                    pos_seg = np.where(multi_class_data_np == 14)
                    pos_seg = np.column_stack(pos_seg)
                    if len(pos_seg) == 0:
                        distances = []
                    else:
                        # print("pos_seg: ", pos_seg)
                        pcom_x_coord = pos_seg[pos_seg[:,0].argsort()][0]
                        # print("pcom_x_coord: ", pcom_x_coord)

                        distances = np.array([calculate_distance_vox(pcom_x_coord, coord, f) for coord in skel_coord_points])
                
                elif b == "M2_M2(L)":
                    pos_seg = np.where(multi_class_data_np == 11)
                    pos_seg = np.column_stack(pos_seg)
                    if len(pos_seg) == 0:
                        distances = []
                    else:
                        # print("pos_seg: ", pos_seg)
                        m1_x_coord = pos_seg[pos_seg[:,0].argsort()][-1]
                        # print("m1_x_coord: ", m1_x_coord)

                        distances = np.array([calculate_distance_vox(m1_x_coord, coord, f) for coord in skel_coord_points])
                
                elif b == "M2_M2(R)":
                    pos_seg = np.where(multi_class_data_np == 9)
                    pos_seg = np.column_stack(pos_seg)
                    # print("pos_seg: ", pos_seg)
                    if len(pos_seg) == 0:
                        distances = []
                    else:
                        m1_x_coord = pos_seg[pos_seg[:,0].argsort()][0]
                        # print("m1_x_coord: ", m1_x_coord)

                        distances = np.array([calculate_distance_vox(m1_x_coord, coord, f) for coord in skel_coord_points])
                
                elif b == "BA top":
                    pos_seg = np.where(multi_class_data_np == 23)
                    pos_seg = np.column_stack(pos_seg)
                    # print("pos_seg: ", pos_seg)
                    if len(pos_seg) == 0:
                        distances = []
                    else:
                        ba_z_coord = pos_seg[pos_seg[:,2].argsort()][-1]
                        ba_z_coord = ba_z_coord - 2
                        # print("ba_z_coord: ", ba_z_coord)

                        distances = np.array([calculate_distance_vox(ba_z_coord, coord, f) for coord in skel_coord_points])
                    
                elif b == "VBJ":
                    pos_seg = np.where(multi_class_data_np == 23)
                    pos_seg = np.column_stack(pos_seg)
                    # print("pos_seg: ", pos_seg)
                    if len(pos_seg) == 0:
                        distances = []
                    else:
                        ba_z_coord = pos_seg[pos_seg[:,2].argsort()][0]
                        ba_z_coord = ba_z_coord + 2
                        # print("ba_z_coord: ", ba_z_coord)

                        distances = np.array([calculate_distance_vox(ba_z_coord, coord, f) for coord in skel_coord_points])

                elif b == "A2_top(L)":
                    pos_seg = np.where(multi_class_data_np == 4)
                    pos_seg = np.column_stack(pos_seg)
                    # print("pos_seg: ", pos_seg)
                    if len(pos_seg) == 0:
                        distances = []
                    else:
                        a2_z_coord = pos_seg[pos_seg[:,2].argsort()][-1]
                        # print("a2_z_coord: ", a2_z_coord)

                        distances = np.array([calculate_distance_vox(a2_z_coord, coord, f) for coord in skel_coord_points])
                
                elif b == "A2_top(R)":
                    pos_seg = np.where(multi_class_data_np == 2)
                    pos_seg = np.column_stack(pos_seg)
                    # print("pos_seg: ", pos_seg)
                    if len(pos_seg) == 0:
                        distances = []
                    else:
                        a2_z_coord = pos_seg[pos_seg[:,2].argsort()][-1]
                        # print("a2_z_coord: ", a2_z_coord)

                        distances = np.array([calculate_distance_vox(a2_z_coord, coord, f) for coord in skel_coord_points])
                
                elif b == "VA_bottom(L)":
                    pos_seg = np.where(multi_class_data_np == 21)
                    pos_seg = np.column_stack(pos_seg)
                    # print("pos_seg: ", pos_seg)
                    if len(pos_seg) == 0:
                        distances = []
                    else:
                        va_z_coord = pos_seg[pos_seg[:,2].argsort()][0]
                        # print("va_z_coord: ", va_z_coord)

                        distances = np.array([calculate_distance_vox(va_z_coord, coord, f) for coord in skel_coord_points])
                
                elif b == "VA_bottom(R)":
                    pos_seg = np.where(multi_class_data_np == 20)
                    pos_seg = np.column_stack(pos_seg)
                    # print("pos_seg: ", pos_seg)
                    if len(pos_seg) == 0:
                        distances = []
                    else:
                        va_z_coord = pos_seg[pos_seg[:,2].argsort()][0]
                        # print("va_z_coord: ", va_z_coord)

                        distances = np.array([calculate_distance_vox(va_z_coord, coord, f) for coord in skel_coord_points])
                
                elif b == "Pcom_P1(L)_for_BA top":
                    pos_seg = np.where(multi_class_data_np == 18)
                    pos_seg = np.column_stack(pos_seg)
                    # print("pos_seg: ", pos_seg)
                    if len(pos_seg) == 0:
                        distances = []
                    else:
                        p1_y_coord = pos_seg[pos_seg[:,1].argsort()][-1]
                        # print("p1_y_coord: ", p1_y_coord)

                        distances = np.array([calculate_distance_vox(p1_y_coord, coord, f) for coord in skel_coord_points])
                    
                elif b == "Pcom_P1(R)_for_BA top":
                    pos_seg = np.where(multi_class_data_np == 16)
                    pos_seg = np.column_stack(pos_seg)
                    # print("pos_seg: ", pos_seg)
                    if len(pos_seg) == 0:
                        distances = []
                    else:
                        p1_y_coord = pos_seg[pos_seg[:,1].argsort()][-1]
                        # print("p1_y_coord: ", p1_y_coord)

                        distances = np.array([calculate_distance_vox(p1_y_coord, coord, f) for coord in skel_coord_points])
                
                if len(distances) == 0:
                    bifurcation_label_pos_dict[b] = []
                else:
                    min_distance = np.min(distances)
                    nearest_coords = skel_coord_points[distances == min_distance]
                    # print("The nearest coordinates are: ", nearest_coords)

                    bifurcation_label_pos_dict[b] = nearest_coords[0]
            
            elif b in ["Pcom_P1(L)_for_ICA top(L)", "Pcom_P1(R)_for_ICA top(R)"]: 
                pos_pcom_skel = np.where(np.isin(multi_class_data_np, bifurcation_label_dict[b]) & (skel_3d == 1))
                pos_pcom_skel = np.column_stack(pos_pcom_skel)
                if len(pos_pcom_skel) == 0:
                    bifurcation_label_pos_dict[b] = []
                else:
                    pos_pcom_skel = pos_pcom_skel[pos_pcom_skel[:,1].argsort()]
                    # print("pos_pcom_skel: ", pos_pcom_skel)
                    if len(pos_pcom_skel) <= 4:
                        bifurcation_label_pos_dict[b] = []
                    else:     
                        vertex, angle = find_smallest_angle(pos_pcom_skel)
                        # print("vertex: ", vertex)
                        # print("angle: ", angle)
                        if len(vertex) == 0:
                            bifurcation_label_pos_dict[b] = []
                        else:
                            vertex[1] = vertex[1] - 2
                            bifurcation_label_pos_dict[b] = vertex
        except:
            pass

    # print("bifurcation_label_pos_dict: ", bifurcation_label_pos_dict)

    bifurcation_points_name_dict = {"A2_A1(L)": ["A2_top(L)", "A2_A1(L)", "ICA top(L)"],
                                    "ICA top(L)": ["M2_M2(L)", "ICA top(L)", "A2_A1(L)"],
                                    "Pcom_ICA(L)": ["ICA top(L)", "Pcom_ICA(L)", "Pcom_P1(L)_for_ICA top(L)"],
                                    "BA top": ["Pcom_P1(L)_for_BA top", "BA top", "Pcom_P1(R)_for_BA top"],
                                    "A2_A1(R)": ["A2_top(R)", "A2_A1(R)", "ICA top(R)"],
                                    "ICA top(R)": ["M2_M2(R)", "ICA top(R)", "A2_A1(R)"],
                                    "Pcom_ICA(R)": ["ICA top(R)", "Pcom_ICA(R)", "Pcom_P1(R)_for_ICA top(R)"],
                                    "VBJ": ["VA_bottom(L)", "VBJ", "VA_bottom(R)"]}

    bifurcation_points_branch_name_dict = {"A2_A1(L)": ["A2(L)", "A1(L)"],
                                    "ICA top(L)": ["M1(L)", "ICA(L)", "A1(L)"],
                                    "Pcom_ICA(L)": ["ICA(L)", "Pcom(L)"],
                                    "BA top": ["P1(L)", "BA", "P1(R)"],
                                    "A2_A1(R)": ["A2(R)", "A1(R)"],
                                    "ICA top(R)": ["M1(R)", "ICA(R)", "A1(R)"],
                                    "Pcom_ICA(R)": ["ICA(R)", "Pcom(R)"],
                                    "VBJ": ["VA(L)", "BA", "VA(R)"]}

    bifurcation_angle_dict = {"A2_A1(L)": 130,
                            "ICA top(L)": 110,
                            "Pcom_ICA(L)": 100,
                            "M2_M2(L)": 90,
                            "BA top": 80,
                            "A2_A1(R)": 130,
                            "ICA top(R)": 110,
                            "Pcom_ICA(R)": 100,
                            "M2_M2(R)": 90,
                            "VBJ": 70}

    for b in bifurcation_points_name_dict.keys():
        try:
            points_name = bifurcation_points_name_dict[b]
            bifurcation_points_branch_dist = []
            for branch_name in bifurcation_points_branch_name_dict[b]:
                bifurcation_points_branch_dist.append(dist_dict[branch_name])

            if np.nan in bifurcation_points_branch_dist and b not in ["BA top"]:
                bifurcation_angle_dict[b] = np.nan
            elif np.nan in bifurcation_points_branch_dist and b in ["BA top"]:
                pass
            else:
                
                    coords_list = []
                    for branch_name in bifurcation_points_branch_name_dict[b]:
                        skel_coord_points = np.where((multi_class_data_np == vessel_label_dict[branch_name]) & (skel_data_np_centerline == 1))
                        skel_coord_points = np.column_stack(skel_coord_points)
                        distances = np.array([calculate_distance_vox(bifurcation_label_pos_dict[b], coord, f) for coord in skel_coord_points])
                        # print("distances: ", distances)
                        dist_diff_abs = np.abs(distances - 5) #5mm
                        min_distance = np.min(dist_diff_abs)
                        coords = skel_coord_points[dist_diff_abs == min_distance]
                        coords_list.append(coords[0])
                    
                    angle = calculate_angle(coords_list[0], bifurcation_label_pos_dict[b], coords_list[1])
                    if angle > 45:
                        angle = bifurcation_angle_dict[b]
                    else:
                        pass
        except:
            pass
            
    M2_dict = {"M2_M2(L)": 12, "M2_M2(R)": 10}
    for b in M2_dict:
        try:
            points = np.where((multi_class_data_np == M2_dict[b]) & (skel_data_np_centerline == 1)) 
            points = np.column_stack(points)
            # print("points.shape: ", points.shape)
            M2_bifurcation = bifurcation_label_pos_dict[b]
            if b == "M2_M2(L)":
                selected_points = points[(points[:,0] >= (M2_bifurcation[0] - 10)) & (points[:,0] < (M2_bifurcation[0] + 20)) & (points[:,1] >= (M2_bifurcation[1] - 20)) & (points[:,1] < (M2_bifurcation[1] + 20)) & (points[:,2] >= (M2_bifurcation[2] - 8)) & (points[:,2] < (M2_bifurcation[2] + 8))]
            elif b == "M2_M2(R)":
                selected_points = points[(points[:,0] > (M2_bifurcation[0] - 20)) & (points[:,0] <= (M2_bifurcation[0] + 10)) & (points[:,1] >= (M2_bifurcation[1] - 20)) & (points[:,1] < (M2_bifurcation[1] + 20)) & (points[:,2] >= (M2_bifurcation[2] - 8)) & (points[:,2] < (M2_bifurcation[2] + 8))]
            # print("selected_points.shape: ", selected_points.shape)
            # print("selected_points: ", selected_points)
            G = create_graph_from_centerline(selected_points, 3)
            edges = list(G.edges)
            # print("edges: ", edges)
            line_1_list = []
            line_1_index_list = []
            for edge in edges:
                if edge[0] == 0:
                    line_1_list.append(selected_points[edge[0]])
                    line_1_index_list.append(edge[0])
                    edge_end = edge[1]
                elif edge[0] == edge_end:
                    line_1_list.append(selected_points[edge[0]])
                    line_1_index_list.append(edge[0])
                    edge_end = edge[1]
                else:
                    pass

            # print("line_1_list: ", line_1_list)
            # print("line_1_index_list: ", line_1_index_list) 
            line_2_index_list = [i for i in range(len(selected_points)) if i not in line_1_index_list]
            line_2_list = [selected_points[i] for i in line_2_index_list]
            # print("line_2_list: ", line_2_list)
            # print("line_2_index_list: ", line_2_index_list)

            line_1_array = np.array(line_1_list)
            line_2_array = np.array(line_2_list)

            distances = np.array([calculate_distance_vox(M2_bifurcation, coord, f) for coord in line_1_array])
            dist_diff_abs = np.abs(distances - 5.5)
            min_distance = np.min(dist_diff_abs)
            line1_coord = line_1_array[dist_diff_abs == min_distance][0]

            distances = np.array([calculate_distance_vox(M2_bifurcation, coord, f) for coord in line_2_array])
            dist_diff_abs = np.abs(distances - 5.5)
            min_distance = np.min(dist_diff_abs)
            line2_coord = line_2_array[dist_diff_abs == min_distance][0]

            angle = calculate_angle(line1_coord, M2_bifurcation, line2_coord)
            # print("line1_coord: ", line1_coord)
            # print("line2_coord: ", line2_coord)
            if angle >= 45:
                bifurcation_angle_dict[b] = angle
            else:
                pass
        except:
                pass

    Lippert_classes = {
        "Anterior class": "a",
        "Posterior class": "a"
    }

    pos_seg_acomm = np.where(multi_class_data_np == 6)
    points_seg_acomm = np.column_stack(pos_seg_acomm)
    # print("points_seg_acomm: ", points_seg_acomm)
    if len(points_seg_acomm) > 0:
        Lippert_classes["Anterior class"] = "a"
    else:
        Lippert_classes["Anterior class"] = "g"

    dist_Lippert_dict = {}
    for a in dist_dict:
        if np.isnan(dist_dict[a]) or dist_dict[a] < 1:
            dist_Lippert_dict[a] = np.nan
        else:
            dist_Lippert_dict[a] = dist_dict[a]
    # print("dist_Lippert_dict: ", dist_Lippert_dict)

    if np.isnan(dist_Lippert_dict['Pcom(L)']) and np.isnan(dist_Lippert_dict['P1(L)']):
        fetaltype_L_flag = False
        Pcomm_L_hpoplasia_absence_flag = True
        P1_L_hpoplasia_absence_flag = True
    elif np.isnan(dist_Lippert_dict['Pcom(L)']) and not np.isnan(dist_Lippert_dict['P1(L)']):
        fetaltype_L_flag = False
        Pcomm_L_hpoplasia_absence_flag = True
        P1_L_hpoplasia_absence_flag = False
    elif not np.isnan(dist_Lippert_dict['Pcom(L)']) and np.isnan(dist_Lippert_dict['P1(L)']):
        fetaltype_L_flag = True
        Pcomm_L_hpoplasia_absence_flag = False
        P1_L_hpoplasia_absence_flag = True
    elif dist_Lippert_dict['Pcom(L)'] <= 1.2 and dist_Lippert_dict['P1(L)'] <= 1.2 and dist_Lippert_dict['Pcom(L)'] >= dist_Lippert_dict['P1(L)']:
        fetaltype_L_flag = True
        Pcomm_L_hpoplasia_absence_flag = False
        P1_L_hpoplasia_absence_flag = False
    elif dist_Lippert_dict['Pcom(L)'] >= (dist_Lippert_dict['P1(L)'] * 1.05):
        fetaltype_L_flag = True
        Pcomm_L_hpoplasia_absence_flag = False
        P1_L_hpoplasia_absence_flag = False
    else:
        fetaltype_L_flag = False 
        Pcomm_L_hpoplasia_absence_flag = False
        P1_L_hpoplasia_absence_flag = False

    if np.isnan(dist_Lippert_dict['Pcom(R)']) and np.isnan(dist_Lippert_dict['P1(R)']):
        fetaltype_R_flag = False
        Pcomm_R_hpoplasia_absence_flag = True
        P1_R_hpoplasia_absence_flag = True
    elif np.isnan(dist_Lippert_dict['Pcom(R)'])and not np.isnan(dist_Lippert_dict['P1(R)']):
        fetaltype_R_flag = False
        Pcomm_R_hpoplasia_absence_flag = True
        P1_R_hpoplasia_absence_flag = False
    elif not np.isnan(dist_Lippert_dict['Pcom(R)']) and np.isnan(dist_Lippert_dict['P1(R)']):
        fetaltype_R_flag = True
        Pcomm_R_hpoplasia_absence_flag = False
        P1_R_hpoplasia_absence_flag = True
    elif dist_Lippert_dict['Pcom(R)'] <= 1.2 and dist_Lippert_dict['P1(R)'] <= 1.2 and dist_Lippert_dict['Pcom(R)'] >= dist_Lippert_dict['P1(R)']:
        fetaltype_R_flag = True
        Pcomm_R_hpoplasia_absence_flag = False
        P1_R_hpoplasia_absence_flag = False
    elif dist_Lippert_dict['Pcom(R)'] >= (dist_Lippert_dict['P1(R)'] * 1.05):
        fetaltype_R_flag = True
        Pcomm_R_hpoplasia_absence_flag = False
        P1_R_hpoplasia_absence_flag = False
    else:
        fetaltype_R_flag = False 
        Pcomm_R_hpoplasia_absence_flag = False
        P1_R_hpoplasia_absence_flag = False

    # print("fetaltype_L_flag: ", fetaltype_L_flag)
    # print("fetaltype_R_flag: ", fetaltype_R_flag)
    # print("Pcomm_L_hpoplasia_absence_flag: ", Pcomm_L_hpoplasia_absence_flag)
    # print("Pcomm_R_hpoplasia_absence_flag: ", Pcomm_R_hpoplasia_absence_flag)
    # print("P1_L_hpoplasia_absence_flag: ", P1_L_hpoplasia_absence_flag)
    # print("P1_R_hpoplasia_absence_flag: ", P1_R_hpoplasia_absence_flag)

    if not fetaltype_L_flag and not fetaltype_R_flag and not Pcomm_L_hpoplasia_absence_flag and not Pcomm_R_hpoplasia_absence_flag and not P1_L_hpoplasia_absence_flag and not P1_R_hpoplasia_absence_flag:
        Lippert_classes["Posterior class"] = "a"
    elif fetaltype_L_flag and fetaltype_R_flag and not Pcomm_L_hpoplasia_absence_flag and not Pcomm_R_hpoplasia_absence_flag and not P1_L_hpoplasia_absence_flag and not P1_R_hpoplasia_absence_flag:
        Lippert_classes["Posterior class"] = "c"
    elif (fetaltype_L_flag or fetaltype_R_flag) and not Pcomm_L_hpoplasia_absence_flag and not Pcomm_R_hpoplasia_absence_flag and not P1_L_hpoplasia_absence_flag and not P1_R_hpoplasia_absence_flag:
        Lippert_classes["Posterior class"] = "b"
    elif not fetaltype_L_flag and not fetaltype_R_flag and Pcomm_L_hpoplasia_absence_flag and Pcomm_R_hpoplasia_absence_flag and not P1_L_hpoplasia_absence_flag and not P1_R_hpoplasia_absence_flag:
        Lippert_classes["Posterior class"] = "e"
    elif not fetaltype_L_flag and not fetaltype_R_flag and (Pcomm_L_hpoplasia_absence_flag or Pcomm_R_hpoplasia_absence_flag) and not P1_L_hpoplasia_absence_flag and not P1_R_hpoplasia_absence_flag:
        Lippert_classes["Posterior class"] = "d"
    elif fetaltype_L_flag and P1_L_hpoplasia_absence_flag and not Pcomm_R_hpoplasia_absence_flag and not P1_R_hpoplasia_absence_flag:
        Lippert_classes["Posterior class"] = "f"
    elif fetaltype_R_flag and P1_R_hpoplasia_absence_flag and not Pcomm_L_hpoplasia_absence_flag and not P1_L_hpoplasia_absence_flag:
        Lippert_classes["Posterior class"] = "f"
    elif fetaltype_L_flag and not P1_L_hpoplasia_absence_flag and Pcomm_R_hpoplasia_absence_flag and not P1_R_hpoplasia_absence_flag:
        Lippert_classes["Posterior class"] = "g"
    elif fetaltype_R_flag and not P1_R_hpoplasia_absence_flag and Pcomm_L_hpoplasia_absence_flag and not P1_L_hpoplasia_absence_flag:
        Lippert_classes["Posterior class"] = "g"
    elif fetaltype_L_flag and P1_L_hpoplasia_absence_flag and Pcomm_R_hpoplasia_absence_flag and not P1_R_hpoplasia_absence_flag:
        Lippert_classes["Posterior class"] = "h"
    elif fetaltype_R_flag and P1_R_hpoplasia_absence_flag and Pcomm_L_hpoplasia_absence_flag and not P1_L_hpoplasia_absence_flag:
        Lippert_classes["Posterior class"] = "h"
    elif fetaltype_L_flag and P1_L_hpoplasia_absence_flag and fetaltype_R_flag and P1_R_hpoplasia_absence_flag:
        Lippert_classes["Posterior class"] = "i"
    elif fetaltype_L_flag and not P1_L_hpoplasia_absence_flag and fetaltype_R_flag and P1_R_hpoplasia_absence_flag:
        Lippert_classes["Posterior class"] = "j"
    elif fetaltype_L_flag and P1_L_hpoplasia_absence_flag and fetaltype_R_flag and not P1_R_hpoplasia_absence_flag:
        Lippert_classes["Posterior class"] = "j"

    # print("Lippert_classes: ", Lippert_classes)

    for k in dist_dict:
        if np.isnan(dist_dict[k]):
            dist_dict[k] = np.nan
        else:
            dist_dict[k] = round(dist_dict[k], 3)

    for k in bifurcation_angle_dict:
        if np.isnan(bifurcation_angle_dict[k]):
            bifurcation_angle_dict[k] = np.nan
        else:
            bifurcation_angle_dict[k] = round(bifurcation_angle_dict[k], 1)

    # print("dist_dict: ", dist_dict)
    # print("bifurcation_angle_dict: ", bifurcation_angle_dict)
    
    save_json_path = "/output/" + case_index
    if not os.path.exists(save_json_path):
        os.makedirs(save_json_path)

    with open(save_json_path + '/result_Lippert.json', 'w', encoding='utf8') as json_file:
        json.dump(Lippert_classes, json_file, indent=4)
    with open(save_json_path + '/results_diameters.json', 'w', encoding='utf8') as json_file:
        json.dump(dist_dict, json_file, indent=4)
    with open(save_json_path + '/results_angles.json', 'w', encoding='utf8') as json_file:
        json.dump(bifurcation_angle_dict, json_file, indent=4)
