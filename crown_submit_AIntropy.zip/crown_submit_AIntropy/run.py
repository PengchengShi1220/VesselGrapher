import subprocess

file_paths = [
    '/crown_example/rename_orientation_same.py',
    '/crown_example/task_run_3d_fullres_998_v2_predict.sh',
    '/crown_example/get_skel_diameter_angle_classes_files.py'
]

for file_path in file_paths:
    if file_path.endswith('.py'):
        proc = subprocess.Popen(['python', file_path])
    if file_path.endswith('.sh'):
        proc = subprocess.Popen(['bash', file_path])
    proc.wait()
