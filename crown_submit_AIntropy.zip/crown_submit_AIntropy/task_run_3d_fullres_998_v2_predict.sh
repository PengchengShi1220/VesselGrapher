#!/bin/bash
CUDA_VISIBLE_DEVICES=0 nnUNetv2_predict -i "/input_nnUNet" -o "/output_3d_multi_class_center_skel" -c 3d_fullres -d Dataset998_angio_MRA_multi_class -tr nnUNetTrainer_NexToU_Plus_multi_class_NoMirroring -f 0 -chk checkpoint_best_epoch288_2e4.pth -nps 1 #-npp 1
